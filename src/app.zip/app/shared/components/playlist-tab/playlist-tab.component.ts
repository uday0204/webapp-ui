import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-playlist-tab",
  templateUrl: "./playlist-tab.component.html",
  styleUrls: ["./playlist-tab.component.scss"]
})
export class PlaylistTabComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
