import { ImagePreloadDirective } from './image-preload.directive';

describe('ImagePreloadDirective', () => {
  it('should create an instance', () => {
    const directive = new ImagePreloadDirective();
    expect(directive).toBeTruthy();
  });
});
