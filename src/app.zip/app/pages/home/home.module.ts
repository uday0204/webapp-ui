import { NgModule } from '@angular/core'; 
 import { CommonModule } from "@angular/common";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { NgZorroAntdModule, NZ_I18N, en_US } from "ng-zorro-antd";
import { SharedModule } from "../../modules/shared/shared.module";
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';

import { IconsProviderModule } from '../../icons-provider.module';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
 import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
 import { NgHttpLoaderModule } from "ng-http-loader"; 
registerLocaleData(en);


 

@NgModule({
  declarations: [
    HomeComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    NgZorroAntdModule,
    FormsModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    SharedModule
  ],
  providers: [{ provide: NZ_I18N, useValue: en_US }]
})

export class HomeModule { }
