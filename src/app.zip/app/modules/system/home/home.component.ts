import {
  Component,
  OnInit,
  TemplateRef,
  ViewChild,
  OnDestroy
} from "@angular/core";
import { HelperService } from "../../core/services/helper.service";
import { environment } from "src/environments/environment";
import { NzDrawerService } from "ng-zorro-antd";
import { AddNewComponent } from "../modals/add-new/add-new.component";
import { InteractionService } from "../../core/services/interaction.service";
import { AppConstants } from "src/app/constants/AppConstants";
import { AuthenticationService } from "../../core/authentication/authentication.service";
import { Role } from "../../shared/model/role";
import { HomeService } from "../home.service";
import { NotificationsComponent } from "../modals/notifications/notifications.component";
import { NotificationsService } from "../notifications.service";
import { MyAccountFormComponent } from "../modals/my-account-form/my-account-form.component";
import { UsersService } from "../configs/users.service";
import { AdminDashboardService } from "../dashboards/admin-dashboard.service";
import { Subscription } from "rxjs";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit, OnDestroy {
  isCollapsed = true;
  windowHeight: any;
  siderHeight: any;
  version: any;
  windowWidth: any;
  antLayoutContentWidth: any;
  @ViewChild("drawerHeader", { static: false }) drawerHeader: TemplateRef<{}>;
  drawerRef: any;
  drawerTitle: any;
  isDataReady: boolean;
  addMenu: any;
  listMenu: any;
  sideMenu: any;
  isAdmin: boolean;
  isDotVisible: boolean;
  notificationIntervalId: any;
  userId: any;
  userOut: any;
  studioOut: any;
  appLogo: any;
  subscription: Subscription;

  constructor(
    private adminDashboardService: AdminDashboardService,
    private usersService: UsersService,
    private helperService: HelperService,
    private drawerService: NzDrawerService,
    private interactionService: InteractionService,
    private authService: AuthenticationService,
    private homeService: HomeService,
    private notificationsService: NotificationsService
  ) { }

  ngOnInit() {
    this.subscription = this.interactionService
      .getInteraction()
      .subscribe(interaction => {
        if (
          interaction.type === "studio_update" &&
          interaction.text === "logo_update"
        ) {
          if (interaction.info && interaction.info.url) {
            this.appLogo = interaction.info.url;
          }
        }
      });
    this.version = environment.version;
    this.isCollapsed = this.helperService.getCollapsedFlag();
    this.getwindowHeight();
    this.getWindowWidth();
    this.prepareData();
    let role = this.helperService.getRole();
    this.isAdmin = false;
    if (role === Role.ADMIN) {
      this.isAdmin = true;
    }
    this.checkeNotification();
  }

  ngOnDestroy(): void {
    clearInterval(this.notificationIntervalId);
  }

  async prepareData() {
    this.userId = this.helperService.loginInfo.id;
    await this.getStudio(AppConstants.MY_STUDIO_ID);
    await this.getUser(this.userId);
    await this.getAddMenu();
    await this.getListMenu();
    console.log(this.addMenu);
    console.log(this.listMenu);
    this.isDataReady = true;
  }

  isValidArr(arr: any) {
    return this.helperService.isValidArr(arr);
  }

  onResize() {
    this.getwindowHeight();
    this.getWindowWidth();
  }

  toggleCollapsedFlag() {
    //this.helperService.toggleCollapsedFlag();
    //this.isCollapsed = this.helperService.getCollapsedFlag();
  }

  getwindowHeight() {
    this.windowHeight = document.documentElement.clientHeight; //window.innerHeight;
    this.siderHeight = this.windowHeight - 85;
  }

  getWindowWidth() {
    this.windowWidth = document.documentElement.clientWidth;
    this.antLayoutContentWidth = this.windowWidth - 400;
  }

  listClickHandler() {
    this.openDrawer("listing", this.listMenu);
  }

  async getStudio(id: any) {
    this.appLogo = this.helperService.defaultAppLogo;
    await this.adminDashboardService
      .getStudio(id)
      .toPromise()
      .then(resp => {
        this.studioOut = resp.entity;
        if (this.studioOut && this.studioOut.studioLogo) {
          this.appLogo = this.studioOut.studioLogo;
        }
      })
      .catch(error => {
        this.studioOut = null;
      });
  }

  async getUser(userId: any) {
    await this.usersService
      .getUser(userId)
      .toPromise()
      .then((resp: any) => {
        this.userOut = resp.entity;
      })
      .catch((error: any) => {
        this.userOut = null;
      });
    this.helperService.userInfo = this.userOut;
  }

  async getAddMenu() {
    await this.homeService
      .getAddMenu()
      .toPromise()
      .then(resp => {
        this.addMenu = resp.entity;
      })
      .catch(error => {
        this.addMenu = null;
      });
  }

  async getListMenu() {
    await this.homeService
      .getListMenu()
      .toPromise()
      .then(resp => {
        this.listMenu = resp.entity;
        if (this.isReportAvailable()) {
          let reportMenu = {
            id: 129,
            actionName: "Report",
            actionDesc: "Report"
          };
          this.listMenu = [...this.listMenu, reportMenu];
        }
        this.sideMenu = this.ignoreConfigMenus(this.listMenu);
        this.sideMenu = this.ignoreNonLinkMenus(this.sideMenu);
        console.log(this.sideMenu);
      })
      .catch(error => {
        this.listMenu = null;
      });
  }

  ignoreConfigMenus(menus) {
    let configMenus = AppConstants.CONFIG_MENU;
    return menus.filter(menu => {
      return !configMenus.includes(menu.actionName);
    });
  }

  ignoreNonLinkMenus(menus: any) {
    return menus.filter(menu => {
      let type = menu.actionName
        .toLowerCase()
        .split(" ")
        .join("");
      return this.helperService.getLink(type);
    });
  }

  getAvatarInfo() {
    let user = {
      firstName: "U",
      lastName: "N",
      thumbnail: ""
    };
    if (this.userOut) {
      if (this.userOut.firstName) {
        user.firstName = this.userOut.firstName;
      }
      if (this.userOut.lastName) {
        user.lastName = this.userOut.lastName;
      }
      if (this.userOut.thumbnail) {
        user.thumbnail = this.userOut.thumbnail;
      }
    }
    /*if (this.helperService.loginInfo) {
      if (this.helperService.loginInfo.firstName) {
        user.firstName = this.helperService.loginInfo.firstName;
      }
      if (this.helperService.loginInfo.lastName) {
        user.lastName = this.helperService.loginInfo.lastName;
      }
      if (this.helperService.loginInfo.thumbnail) {
        user.thumbnail = this.helperService.loginInfo.thumbnail;
      }
    }*/

    return {
      ...user,
      size: "medium"
    };
  }

  async addClickHandler() {
    this.openDrawer("add", this.addMenu);
  }
  logoutHandler() {
    this.authService.logout();
  }
  profileHandler() {
    console.log("profileHandler");
    this.drawerTitle = "My Account";
    this.drawerRef = this.drawerService.create<
      MyAccountFormComponent,
      { userOut: any },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: MyAccountFormComponent,
      nzContentParams: {
        userOut: this.userOut
      },
      nzClosable: false,
      nzWrapClassName: "modal-wrapper",
      nzWidth: "30%"
    });

    this.drawerRef.afterOpen.subscribe(() => {
      console.log("MyAccountFormComponent");
    });

    this.drawerRef.afterClose.subscribe(isSuccess => {
      console.log("MyAccountFormComponent " + isSuccess);
      if (isSuccess) {
        this.getUser(this.userId);
      }
    });
  }
  openDrawer(actionType: string, menuArr: any): void {
    this.drawerTitle = actionType === "add" ? "Add New " : "Listing";
    this.drawerRef = this.drawerService.create<
      AddNewComponent,
      { actionType: string; menuArr: any },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: AddNewComponent,
      nzContentParams: {
        actionType: actionType,
        menuArr: menuArr
      },
      nzClosable: false,
      nzWrapClassName: "modal-wrapper",
      nzWidth: "25%"
    });

    this.drawerRef.afterOpen.subscribe(() => {
      console.log("Drawer(Component) open");
    });

    this.drawerRef.afterClose.subscribe(data => {
      console.log("afterClose DATA " + data);
    });
  }

  /*getRouterLink(type: any) {
    if (type === "list") {
      return "/system/listing/configs";
    } else if (type === "dashboard") {
      return "/system/dashboard";
    } else if (type === "time-sheet") {
      return "/system/listing/time-sheet";
    } else if (type === "playlist") {
      return "/system/listing/playlist";
    }
  }*/

  closeAddNewForm(): void {
    this.drawerRef.close();
  }

  dashboardMenu = {
    actionName: "Dashboard"
  };

  getRouterLinkNew(menu: any) {
    let link = "";
    switch (menu.actionName) {
      case "Dashboard":
        return "/system/dashboard";
        break;
      case "Show":
        return "/system/listing/shows";
        break;
      case "Playlist":
        return "/system/listing/playlist";
        break;
      case "Time Sheet":
        return "/system/listing/time-sheet";
        break;
      case "Time Sheet Review":
        return "/system/listing/time-sheet-review";
        break;
      case "My Task":
        return "/system/listing/tasks";
        break;
      case "Report":
        return "/system/listing/report";
        break;
      case "Daybook":
        return "/system/listing/daybook";
        break;
      case "Favourites":
        return "/system/listing/favourites";
        break;

      default:
        break;
    }
    return link;
  }

  getIconOld() {
    return `<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
    <path d="M0 0h24v24H0z" fill="none" />
    <path
      d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z" />
  </svg>`;
  }
  getIcon(menu: any) {
    let icon = "";
    switch (menu) {
      case "Show":
        return "desktop";
        break;
      case "Playlist":
        return "play-square";
        break;
      case "Time Sheet":
        return "calendar";
        break;
      case "Time Sheet Review":
        return "schedule";
        break;
      case "My Task":
        return "desktop";
        break;
      case "list":
        return "unordered-list";
        break;
      case "Report":
        return "bar-chart";
        break;
      case "Daybook":
        return "read";
        break;
      case "Favourites":
        return "tags";
        break;
      default:
        break;
    }
    return icon;
  }

  bellHandler() {
    //this.isDotVisible = false;
    this.drawerTitle = "Notifications";
    this.drawerRef = this.drawerService.create<
      NotificationsComponent,
      {},
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: NotificationsComponent,
      nzContentParams: {},
      nzClosable: false,
      nzWrapClassName: "modal-wrapper",
      nzWidth: "50%"
    });

    this.drawerRef.afterOpen.subscribe(() => {
      console.log("Drawer(Component) open");
    });

    this.drawerRef.afterClose.subscribe(data => {
      //this.isDotVisible = true;
      console.log("afterClose DATA " + data);
    });
  }

  isReportAvailable() {
    let reportAvailableRoles = [Role.HOS, Role.PRODUCER, Role.SUPERVISOR];
    let currentUserRole = this.helperService.getRole();
    if (reportAvailableRoles.indexOf(currentUserRole) === -1) {
      return false;
    }
    return true;
  }

  async checkeNotification() {
    let page = {
      pageNumber: 0,
      size: 5,
      search: "",
      sortBy: "",
      orderBy: ""
    };
    console.log(
      "checkeNotification latestTimeStamp >> " +
      this.helperService.latestTimeStamp
    );
    if (!this.helperService.latestTimeStamp) {
      await this.notificationsService
        .getNotificationList(page)
        .toPromise()
        .then(resp => {
          console.log("checkeNotification resp >> ");
          if (resp && resp.valid) {
            if (page.pageNumber == 0 && resp.coll && resp.coll[0].createdDate) {
              this.helperService.latestTimeStamp = resp.coll[0].createdDate;
            }
          }
        })
        .catch(error => {
          console.log("checkeNotification error >> ");
        });
    }
    console.log(
      "checkeNotification latestTimeStamp >> " +
      this.helperService.latestTimeStamp
    );
    this.notificationIntervalId = setInterval(() => {
      this.notificationsService
        .checkNewNotifications(this.helperService.latestTimeStamp)
        .subscribe(
          resp => {
            console.log("checkNewNotifications resp " + resp);
            this.isDotVisible = resp.entity;
          },
          error => {
            console.log("checkNewNotifications error " + error);
          }
        );
    }, AppConstants.NOTIFICATION_INTERVAL);
  }
}
