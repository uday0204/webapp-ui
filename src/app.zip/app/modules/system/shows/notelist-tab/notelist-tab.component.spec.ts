import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotelistTabComponent } from './notelist-tab.component';

describe('NotelistTabComponent', () => {
  let component: NotelistTabComponent;
  let fixture: ComponentFixture<NotelistTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotelistTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotelistTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
