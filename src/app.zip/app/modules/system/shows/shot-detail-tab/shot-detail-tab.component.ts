import { Component, OnInit, Input } from '@angular/core';
import { HelperService } from 'src/app/modules/core/services/helper.service';

@Component({
  selector: 'app-shot-detail-tab',
  templateUrl: './shot-detail-tab.component.html',
  styleUrls: ['./shot-detail-tab.component.scss']
})
export class ShotDetailTabComponent implements OnInit {

  @Input() shotIn: any;
  constructor(private helperService: HelperService) { }

  ngOnInit() {
  }

  displayDate(dateStr) {
    if (dateStr) {
      return this.helperService.transformDate(new Date(dateStr));
    } else {
      return '';
    }
  }



}
