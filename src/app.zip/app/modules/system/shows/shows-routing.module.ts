import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { ShowListComponent } from "./show-list/show-list.component";
import { ShowDetailComponent } from "./show-detail/show-detail.component";
import { ShotDetailComponent } from "./shot-detail/shot-detail.component";
import { AssetDetailComponent } from "./asset-detail/asset-detail.component";
import { TaskDetailComponent } from "./task-detail/task-detail.component";

import { AuthGuard } from "../../core/authentication/auth.guard";
import { Role } from "../../shared/model/role";
import { NoteDetailComponent } from "./note-detail/note-detail.component";

// const routes: Routes = [
//   { path: "", component: ShowListComponent },
//   { path: ":showId/shots/:shotId", component: ShotDetailComponent },
//   { path: ":showId/shots", component: ShowDetailComponent },
//   { path: ":showId", redirectTo: ':showId/shots', pathMatch: 'full' }
// ];
//const rolesAllowed = [Role.SUPERVISOR, Role.PRODUCER, Role.IO];
const routes: Routes = [
  {
    path: "",
    component: ShowListComponent,
    canActivate: [AuthGuard],
    data: { permission: "Show" }
  },
  {
    path: ":showId/assets/:assetId/tasks",
    redirectTo: ":showId/assets/:assetId",
    pathMatch: "full"
  },
  {
    path: ":showId/assets/:assetId/tasks/:taskId",
    component: TaskDetailComponent,
    canActivate: [AuthGuard],
    data: { permission: "Task" }
  },
  {
    path: ":showId/shots/:shotId/tasks",
    redirectTo: ":showId/shots/:shotId",
    pathMatch: "full"
  },
  {
    path: ":showId/shots/:shotId/tasks/:taskId",
    component: TaskDetailComponent,
    canActivate: [AuthGuard],
    data: { permission: "Task" }
  },
  { path: ":showId/assets", redirectTo: ":showId", pathMatch: "full" },
  {
    path: ":showId/assets/:assetId",
    component: AssetDetailComponent,
    canActivate: [AuthGuard],
    data: { permission: "Asset" }
  },
  {
    path: ":showId/shots/:shotId",
    component: ShotDetailComponent,
    canActivate: [AuthGuard],
    data: { permission: "Shot" }
  },
  // {
  //   path: ":showId/notes/:noteId",
  //   component: NoteDetailComponent,
  //   canActivate: [AuthGuard],
  //   data: { permission: "Show" }
  // },
  { path: ":showId/shots", redirectTo: ":showId", pathMatch: "full" },
  {
    path: ":showId",
    component: ShowDetailComponent,
    canActivate: [AuthGuard],
    data: { permission: "Show" }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ShowsRoutingModule {}
