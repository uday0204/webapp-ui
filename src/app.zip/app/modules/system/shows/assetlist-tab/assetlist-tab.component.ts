import {
  Component,
  OnInit,
  Input,
  ViewChild,
  TemplateRef,
  OnDestroy
} from "@angular/core";
import { Page } from "src/app/modules/shared/model/page";
import { AppConstants } from "src/app/constants/AppConstants";
import { ShowsService } from "../shows.service";
import { NotificationService } from "src/app/modules/core/services/notification.service";
import { Router } from "@angular/router";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { AssetsService } from "../assets.service";
import {
  NzDrawerService,
  UploadChangeParam,
  NzModalService
} from "ng-zorro-antd";
import { AssetFormComponent } from "../../modals/asset-form/asset-form.component";
import { TasksService } from "../tasks.service";
import { ShotFilterSettingsComponent } from "../../modals/shot-filter-settings/shot-filter-settings.component";
import { InteractionService } from "src/app/modules/core/services/interaction.service";
import { Subscription } from "rxjs";

@Component({
  selector: "app-assetlist-tab",
  templateUrl: "./assetlist-tab.component.html",
  styleUrls: ["./assetlist-tab.component.scss"]
})
export class AssetlistTabComponent implements OnInit, OnDestroy {
  @Input() showIn: any;
  @ViewChild("myTable", { static: false }) table: any;
  @ViewChild("drawerHeader", { static: false }) drawerHeader: TemplateRef<{}>;
  @Input() isReadOnly: boolean;

  isEmptyData: boolean;
  isDataReady: boolean;
  showDummy: boolean;
  childDrawerRef: any;
  isLoading: boolean = true;
  rows: any;
  showId: any;
  page = new Page();
  pageSizeOptions: any;
  selectedPageSize: any;
  editing = {};
  tableColumns: any;
  selectedTableColumns: any;
  isEditSuccess: boolean;
  assetToDelete: any;
  isAlertVisible: boolean;
  drawerTitle: any;

  /** Dropdown inline edit vars - START */
  isVisible: boolean;
  modalTitle: any;
  myrow: any;
  mycol: any;

  isStatusSelect: boolean;
  statuses: any;
  selectedStatus: any;

  isTaskTemplateSelect: boolean;
  selectedTaskTemplateId: any;
  taskTemplates: any;

  isAssetTypeSelect: boolean;
  selectedAssetTypeId: any;
  assetTypes: any;
  assetOut: any;
  currPageInfo: any;

  isThumbnailSelect: boolean;
  selectedThumbnailUrl: any;

  /** Dropdown inline edit vars - END*/

  selected = [];
  taskProgress: any;
  isProgressVisible: boolean;
  progressConfig: any;

  isSearching: boolean;
  searchPattern = "";

  assetFilters: any;
  sortBy: any = "";
  orderBy: any = "";
  subscription: Subscription;
  tableHeight: any = "calc(100vh - 200px)";

  constructor(
    private showsService: ShowsService,
    private assetsService: AssetsService,
    private notificationService: NotificationService,
    private router: Router,
    private helperService: HelperService,
    private interactionService: InteractionService,
    private drawerService: NzDrawerService,
    private modalService: NzModalService,
    private tasksService: TasksService
  ) {
    this.page.pageNumber = 0;
    this.page.size = 10;
    this.pageSizeOptions = AppConstants.TABLE_PAGE_SIZE_OPTIONS;
    this.selectedPageSize = this.page.size; //.toString();
  }

  ngOnInit() {
    this.isReadOnly = this.helperService.isReadOnly("Asset");
    this.progressConfig = {
      showInfo: true,
      type: "circle",
      strokeLinecap: "round",
      strokeWidth: 8,
      strokeColor: "#3be582"
    };
    this.showId = this.showIn.id;
    /*this.helperService.isGlobalAddEnabled = false;
    this.subscription = this.interactionService
      .getInteraction()
      .subscribe(interaction => {
        if (interaction.type === "global-add") {
          this.createAsset();
        }
      });*/
    this.getStatuses();
    this.getTableColumns();
    this.assetFilters = {
      seasonIds: [],
      episodeIds: [],
      sequenceIds: [],
      spotIds: [],
      status: []
    };
  }

  ngOnDestroy() {
    //this.subscription.unsubscribe();
  }

  getTableColumns() {
    this.tableColumns = [
      {
        name: "assetName",
        displayName: "Asset Name",
        defaultDisplay: true,
        sortable: true,
        isEditable: false
      },
      {
        name: "thumbnail",
        displayName: "Thumbnail",
        defaultDisplay: true,
        sortable: false,
        isEditable: this.isReadOnly ? false : true
      },
      {
        name: "description",
        displayName: "Description",
        defaultDisplay: true,
        sortable: false,
        isEditable: this.isReadOnly ? false : true
      },
      {
        name: "status",
        displayName: "Status",
        defaultDisplay: true,
        sortable: true,
        isEditable: this.isReadOnly ? false : true
      },
      {
        name: "creativeBrief",
        displayName: "Creative Brief",
        defaultDisplay: true,
        sortable: true,
        isEditable: this.isReadOnly ? false : true
      },
      {
        name: "templateName",
        displayName: "Template Name",
        defaultDisplay: true,
        sortable: true,
        isEditable: false
      },
      {
        name: "assetTypeName",
        displayName: "Asset Type",
        defaultDisplay: true,
        sortable: true,
        isEditable: false
      },
      {
        name: "completionPercentage",
        displayName: "Completion Percentage",
        defaultDisplay: true,
        sortable: false,
        isEditable: false
      }
    ];
    this.frameSelectedColumns();
    this.isDataReady = true;
  }

  frameSelectedColumns() {
    this.selectedTableColumns = this.tableColumns.filter((item, index) => {
      item["index"] = index;
      return item.defaultDisplay;
    });
  }

  searchHandler() {
    this.isSearching = true;
  }

  searchDetails() {
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  searchBlur() {
    if (this.searchPattern == "") {
      this.isSearching = false;
    }
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  onSelect({ selected }) {
    if (selected) {
      this.selected.splice(0, this.selected.length);
      this.selected.push(...selected);
    }
  }

  progressHandler() {
    let selectedIds = this.selected.map(item => {
      return item.id;
    });

    this.tasksService
      .getTaskProgressByAsset(selectedIds)
      .toPromise()
      .then(resp => {
        this.isProgressVisible = true;
        if (resp && resp.entity) {
          this.taskProgress = Math.round(resp.entity);
        } else {
          this.taskProgress = 0;
        }
      })
      .catch(error => {});
  }

  setPageSize() {
    let pageInfo = {
      pageSize: this.selectedPageSize,
      offset: 0
    };
    this.setPage(pageInfo);
  }

  getId(row: any) {
    return row.id;
  }

  setPage(pageInfo) {
    // console.log('setPage ' + JSON.stringify(pageInfo));
    this.currPageInfo = pageInfo;
    this.isLoading = true;
    this.page.pageNumber = pageInfo.offset;
    this.page.size = pageInfo.pageSize;
    this.page.search = this.searchPattern;
    this.page.sortBy = this.sortBy;
    this.page.orderBy = this.orderBy;
    this.showDummy = true;
    let filterParams = this.getFilterParams();
    this.assetsService
      .getAssetTableList(this.page, this.showId, filterParams)
      .subscribe(
        resp => {
          if (resp && resp.valid) {
            this.page.totalElements = resp.total;
            this.page.totalPages = Math.ceil(resp.total / this.page.size);
            this.rows = resp.coll;
            setTimeout(() => {
              this.isLoading = false;
              this.table.recalculate();
              try {
                let parentHeight = this.table.bodyComponent.scroller.parentElement.getBoundingClientRect()
                  .height;
                let childHeight = this.table.bodyComponent.scroller.element.getBoundingClientRect()
                  .height;
                if (childHeight > parentHeight) {
                  this.showDummy = false;
                } else {
                  this.showDummy = true;
                }
                if (this.rows.length <= 10) {
                  this.showDummy = true;
                }
              } catch (e) {}
            }, 500);
          } else {
            this.isLoading = false;
            this.onDataError(resp);
          }
          this.setTableHeight();
        },
        error => {
          this.isLoading = false;
          this.onDataError(error);
        }
      );
  }

  onDataError(error: any) {
    console.log("<< onDataError >> " + error);
    this.isEmptyData = true;
  }

  createAsset() {
    this.drawerTitle = "Add Asset";
    let assetOut = {
      showId: this.showId
    };
    this.openAssetForm("create", assetOut);
  }

  async editHandler(row: any) {
    await this.getAsset(row.id);
    if (this.assetOut) {
      this.drawerTitle = "Edit Asset";
      this.openAssetForm("update", this.assetOut);
    }
  }

  async getAsset(id: any) {
    await this.assetsService
      .getAsset(id)
      .toPromise()
      .then(resp => {
        this.assetOut = resp.entity;
      })
      .catch(error => {
        console.log(error);
        this.assetOut = null;
      });
  }

  openAssetForm(mode: any, assetOut: any): void {
    this.childDrawerRef = this.drawerService.create<
      AssetFormComponent,
      {
        assetOut: any;
        mode: string;
        disableShowSelect?: boolean;
        showName?: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: AssetFormComponent,
      nzContentParams: {
        assetOut: assetOut,
        mode: mode,
        disableShowSelect: true,
        showName: this.showIn.showName
      },
      nzClosable: false,
      nzWidth: "30%",
      nzWrapClassName: "modal-wrapper",
      nzOnCancel: () =>
        new Promise((resolve, reject) => {
          this.modalService.confirm({
            nzTitle: AppConstants.EXIT_WARNING_MESSAGE,
            nzOkText: "Yes",
            nzOkType: "default",
            nzOnOk: () => resolve(true),
            nzCancelText: "No",
            //nzCancelType: "primary",
            nzOnCancel: () => resolve(false)
          });
          return;
        })
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("Asset Form Open");
    });

    this.childDrawerRef.afterClose.subscribe(isSuccess => {
      console.log("childDrawerRef afterClose DATA " + isSuccess);
      if (isSuccess) {
        this.setPage(this.currPageInfo);
      }
    });
  }

  closeForm(): void {
    this.childDrawerRef.close();
  }

  deleteHandler(row: any) {
    this.isAlertVisible = true;
    this.assetToDelete = row;
  }

  deleteAssetConfirm = async () => {
    console.log("Delete Asset " + this.assetToDelete.id);
    let successMessage = "Asset has been successfully deleted.";
    let errorMessage = "Asset deletion failed.";
    this.isAlertVisible = false;
    await this.assetsService
      .deleteAsset(this.assetToDelete.id)
      .toPromise()
      .then(resp => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: successMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
        this.setPage(this.currPageInfo);
      })
      .catch(error => {
        let errorDetails = this.helperService.getErrorDetails(error);
        if (errorDetails !== "") {
          errorMessage = `<b>${errorMessage}</b>` + errorDetails;
        }
        this.showNotification({
          type: "error",
          title: "Error",
          content: errorMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  };

  deleteAssetCancel = () => {
    this.isAlertVisible = false;
    console.log("deleteAssetCancel ");
  };

  onAssetNameClick(row: any) {
    let routerLink = this.router.url + "/assets/" + row.id;
    this.router.navigate([routerLink]);
  }

  onSort(event) {
    console.log("Sort Event", event);
    this.sortBy = event.sorts[0].prop;
    this.orderBy = event.sorts[0].dir.toUpperCase();
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  getColWidth(colName: any) {
    if (colName === "completionPercentage") {
      return 250;
    }
    return 250;
  }

  getStatusColorCode(row: any) {
    //console.log(row);
    let defaultCode = "#038e4e";
    let matched = this.helperService.findObjectInArrayByKey(
      this.statuses,
      "value",
      row.status
    );
    //console.log(this.statuses);
    //console.log(matched);
    return matched && matched.code ? matched.code : defaultCode;
    /*
    let code = '#038e4e';
    if (matched && matched.code) {
      code = matched.code;
    }
    return code;*/
  }

  enableEdit(row: any, col: any) {
    console.log(this.editing);
    this.resetEditFlags();
    this.editing[row.id + "-" + col.name] = true;
  }

  resetEditFlags() {
    for (let key in this.editing) {
      if (this.editing.hasOwnProperty(key)) {
        this.editing[key] = false;
      }
    }
  }

  inlineEditHandler(row: any, col: any) {
    this.resetEditFlags();
    this.myrow = row;
    this.mycol = col;

    this.isStatusSelect = false;
    this.isTaskTemplateSelect = false;
    this.isAssetTypeSelect = false;
    this.isThumbnailSelect = false;
    this.modalTitle = "";

    if (col.name === "status") {
      this.modalTitle = "Edit Status";
      this.selectedStatus = row.status;
      this.isStatusSelect = true;
      //this.getStatuses();
    } else if (col.name === "templateName") {
      this.modalTitle = "Edit Task Template";
      this.selectedTaskTemplateId = row.taskTemplateId;
      this.isTaskTemplateSelect = true;
      this.getTaskTemplates();
    } else if (col.name === "assetTypeName") {
      this.modalTitle = "Edit Asset Type";
      this.selectedAssetTypeId = row.assetTypeId;
      this.isAssetTypeSelect = true;
      this.getAssetTypes();
    } else if (col.name === "thumbnail") {
      this.modalTitle = "Edit Thumbnail";
      this.selectedThumbnailUrl = row.thumbnail;
      this.isThumbnailSelect = true;
    }
    if (this.modalTitle !== "") {
      this.showModal();
    }
  }

  async inlineEditConfirm(row: any, col: any) {
    let assetId = row.id;
    let assetIn: any;
    this.isVisible = false;
    if (col.name === "status") {
      console.log(this.selectedStatus + " : " + row.status);
      this.isStatusSelect = false;
      if (this.selectedStatus !== row.status) {
        assetIn = {
          type: "status",
          status: row.status
        };
        await this.updateConfirm(row, col, assetId, assetIn);
      }
    } else if (col.name === "thumbnail") {
      console.log(this.selectedThumbnailUrl + " : " + row.thumbnail);
      this.isThumbnailSelect = false;
      assetIn = {
        type: "thumbnail",
        thumbnail: row.thumbnail
      };
      await this.updateConfirm(row, col, assetId, assetIn);
    }
  }

  inlineEditCancel(row: any, col: any) {
    this.isVisible = false;
    if (col.name === "status") {
      this.isStatusSelect = false;
      row.status = this.selectedStatus;
    } else if (col.name === "thumbnail") {
      this.isThumbnailSelect = false;
      row.thumbnail = this.selectedThumbnailUrl;
    }
  }

  onUploadChange(e: UploadChangeParam) {
    console.log("^^^ *** " + e.type);
    if (e.type === "success") {
      this.myrow.thumbnail = e.file.response.fileDownloadUri;
    }
    if (e.type === "removed") {
      this.myrow.thumbnail = "";
    }
  }

  showModal(): void {
    this.isVisible = true;
  }

  isValidArr(arr: any) {
    return this.helperService.isValidArr(arr);
  }

  showNotification(info: any) {
    this.notificationService.showNotification(info);
  }

  addColorCodes(statuses: any) {
    let colorCodes = AppConstants.SHOT_STATUS_CODES;
    statuses.map((item: any) => {
      item.code = colorCodes[item.value];
      return item;
    });
  }

  filterHandler() {
    this.drawerTitle = "Filter Settings";
    this.openFilterSettingsForm();
  }

  openFilterSettingsForm(): void {
    this.childDrawerRef = this.drawerService.create<
      ShotFilterSettingsComponent,
      {
        type: any;
        filters: any;
        showId: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: ShotFilterSettingsComponent,
      nzContentParams: {
        type: "asset",
        filters: this.assetFilters,
        showId: this.showId
      },
      nzClosable: false,
      nzWidth: "40%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("childDrawerRef Drawer(Component) open");
    });

    this.childDrawerRef.afterClose.subscribe(data => {
      if (data) {
        if (JSON.stringify(this.assetFilters) !== JSON.stringify(data)) {
          this.assetFilters = data;
          this.currPageInfo.offset = 0;
          this.setPage(this.currPageInfo);
        } else {
          console.log("No change in the settings : Do nothing !!! ");
        }
      }
    });
  }

  getFilterParams() {
    let filterParams = "";
    for (let i in this.assetFilters) {
      let item = this.assetFilters[i];
      if (item && item.length > 0) {
        if (filterParams != "") {
          filterParams += "&";
        }
        filterParams += `${i}=${item.toString()}`;
      }
    }
    return filterParams;
  }

  async updateValue(row: any, col: any, event: any) {
    if (row[col.name] != event.target.value) {
      let assetId = row.id;
      let assetIn = {
        type: col.name
      };
      assetIn[col.name] = event.target.value;
      await this.updateConfirm(row, col, assetId, assetIn);
    }
    if (this.isEditSuccess) {
      row[col.name] = event.target.value;
    }
    this.editing[row.id + "-" + col.name] = false;
  }

  async updateConfirm(row: any, col: any, assetId: any, assetIn: any) {
    this.isEditSuccess = false;
    let errorMessage = "Record update failed.";
    await this.assetsService
      .inlineEdit(assetId, assetIn)
      .toPromise()
      .then((resp: any) => {
        console.log("update success ");
        this.isEditSuccess = true;
      })
      .catch((error: any) => {
        console.log("update failed ");
        let errorDetails = this.helperService.getErrorDetails(error);
        if (errorDetails !== "") {
          errorMessage = `<b>${errorMessage}</b>` + errorDetails;
        }
        this.isEditSuccess = false;
      });
    if (this.isEditSuccess) {
      this.showNotification({
        type: "success",
        title: "Success",
        content: "Record updated successfully.",
        duration: AppConstants.NOTIFICATION_DURATION
      });
    } else {
      this.showNotification({
        type: "error",
        title: "Error",
        content: errorMessage,
        duration: AppConstants.NOTIFICATION_DURATION
      });
    }
  }

  async getStatuses() {
    await this.showsService
      .getAllStatus()
      .toPromise()
      .then((resp: any) => {
        this.statuses = resp.entity;
        this.addColorCodes(this.statuses);
      })
      .catch((error: any) => {
        this.statuses = [];
      });
  }

  async getTaskTemplates() {
    await this.showsService
      .getTaskTemplates()
      .toPromise()
      .then((resp: any) => {
        this.taskTemplates = resp.entity;
      })
      .catch((error: any) => {
        this.taskTemplates = [];
      });
  }

  async getAssetTypes() {
    await this.assetsService
      .getAssetTypes()
      .toPromise()
      .then((resp: any) => {
        this.assetTypes = resp.entity;
      })
      .catch((error: any) => {
        this.assetTypes = [];
      });
  }

  setTableHeight() {
    if (!this.isValidArr(this.rows)) {
      this.tableHeight = 150 + "px";
    } else {
      if (this.rows.length <= 10) {
        this.tableHeight = this.rows.length * 50 + 120 + "px";
      } else {
        this.tableHeight = "calc(100vh - 300px)";
      }
    }
  }

  getTableHeight() {
    return this.tableHeight;
  }
}
