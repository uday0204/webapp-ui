import {
  Component,
  OnInit,
  Input,
  ViewChild,
  TemplateRef
} from "@angular/core";
import { ShowsService } from "../shows.service";
import { NzDrawerService, NzModalService } from "ng-zorro-antd";
import { NotificationService } from "src/app/modules/core/services/notification.service";
import { Router } from "@angular/router";
import { Page } from "src/app/modules/shared/model/page";
import { TableColumnsSettingsComponent } from "../../modals/table-columns-settings/table-columns-settings.component";
import { AppConstants } from "src/app/constants/AppConstants";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { TaskFormComponent } from "../../modals/task-form/task-form.component";
import { WorkstatusService } from "../../configs/workstatus.service";
import { TasksService } from "../tasks.service";
import { ShotFilterSettingsComponent } from "../../modals/shot-filter-settings/shot-filter-settings.component";
import { Subscription } from "rxjs";
import { InteractionService } from "src/app/modules/core/services/interaction.service";
import { NoteFormComponent } from "../../modals/note-form/note-form.component";

@Component({
  selector: "app-tasklist-tab",
  templateUrl: "./tasklist-tab.component.html",
  styleUrls: ["./tasklist-tab.component.scss"]
})
export class TasklistTabComponent implements OnInit {
  @Input() showIn: any;
  @Input() shotIn: any;
  @Input() assetIn: any;
  @Input() isRowGroupEnabled: boolean;
  @Input() isReadOnly: boolean;
  @ViewChild("myTable", { static: false }) table: any;
  @ViewChild("myGroupHeader", { static: false }) groupHeader: any;
  @ViewChild("drawerHeader", { static: false }) drawerHeader: TemplateRef<{}>;

  showDummy: boolean;
  childDrawerRef: any;
  isEmptyData: boolean;
  isDataReady: boolean;
  isLoading: boolean = true;
  rows: any;
  showId: any;
  shotId: any;
  assetId: any;
  page = new Page();
  selectedPageSize: any;
  editing = {};
  tableColumns: any;
  selectedTableColumns: any;
  intervalId: any;
  isEditSuccess: boolean;
  taskOut: any;
  isAlertVisible: boolean;
  taskToDelete: any;
  pageSizeOptions: any;
  /** Dropdown inline edit vars - START */
  isVisible: boolean;
  modalTitle: any;
  myrow: any;
  mycol: any;

  isArtistSelect: boolean;
  artists: any;
  selectedArtistId: any;

  isSupervisorSelect: boolean;
  supervisors: any;
  selectedSupervisorId: any;

  isPrioritySelect: boolean;
  taskPriorities: any;
  selectedPriorityId: any;

  isWorkStatusSelect: boolean;
  workStatuses: any;
  selectedWorkStatusId: any;

  /** Dropdown inline edit vars - END*/
  drawerTitle: any;
  currPageInfo: any;

  selected = [];
  taskProgress: any;
  isProgressVisible: boolean;
  progressConfig: any;

  isSearching: boolean;
  searchPattern = "";

  taskFilters: any;
  sortBy: any = "";
  orderBy: any = "";
  taskInfo: any;
  subscription: Subscription;
  showName: any;
  type: any = "shot";
  groupBy: any;
  //tableHeight: any = 'calc(100vh - 200px)';
  tableHeight: any = "calc(100vh - 300px)";

  constructor(
    private showsService: ShowsService,
    private workstatusService: WorkstatusService,
    private drawerService: NzDrawerService,
    private modalService: NzModalService,
    private notificationService: NotificationService,
    private router: Router,
    private helperService: HelperService,
    private tasksService: TasksService,
    private interactionService: InteractionService
  ) {
    this.page.pageNumber = 0;
    this.page.size = 10;
    this.pageSizeOptions = AppConstants.TABLE_PAGE_SIZE_OPTIONS;
    this.selectedPageSize = this.page.size; //.toString();
  }

  ngOnInit() {
    this.isReadOnly = this.helperService.isReadOnly("Task");
    /*this.helperService.isGlobalAddEnabled = false;
    this.subscription = this.interactionService
      .getInteraction()
      .subscribe(interaction => {
        if (interaction.type === "global-add") {
          this.createTask();
        }
      });*/
    this.progressConfig = {
      showInfo: true,
      type: "circle",
      strokeLinecap: "round",
      strokeWidth: 8,
      strokeColor: "#3be582"
    };
    this.type = "shot";
    if (this.showIn) {
      this.showId = this.showIn.id;
      this.taskInfo = {
        showId: this.showId
      };
      this.showName = this.showIn.showName;
    } else if (this.shotIn) {
      this.showId = this.shotIn.showId;
      this.shotId = this.shotIn.id;
      this.taskInfo = {
        showId: this.showId,
        shotId: this.shotId
      };
      this.showName = this.shotIn.showName;
    } else if (this.assetIn) {
      this.type = "asset";
      this.showId = this.assetIn.showId;
      this.assetId = this.assetIn.id;
      this.taskInfo = {
        showId: this.showId,
        assetId: this.assetId
      };
      this.showName = this.assetIn.showName;
    }
    this.taskFilters = {
      seasonIds: [],
      episodeIds: [],
      sequenceIds: [],
      spotIds: [],
      workStatusIds: [],
      taskPriorityIds: [],
      complexityIds: [],
      artistIds: [],
      accountableIds: []
    };
    this.getWorkstatusList();
    this.getTableColumns();
    this.setGroupByValue();
  }

  onTaskNameClick(row: any) {
    let routerLink = "";
    let taskInfo = {};
    if (this.isRowGroupEnabled) {
      if (this.type === "shot") {
        routerLink =
          this.router.url + "/shots/" + row.shotId + "/tasks/" + row.id;
        /*taskInfo = {
          showName: this.showName,
          shotName: row.shotCode
        };*/
      } else {
        /*taskInfo = {
          showName: this.showName,
          assetName: row.assetName
        };*/

        routerLink =
          this.router.url + "/assets/" + row.assetId + "/tasks/" + row.id;
      }
    } else {
      routerLink = this.router.url + "/tasks/" + row.id;
    }
    if (routerLink !== "") {
      /*this.navigationExtras = {
        state: taskInfo
      };*/
      //this.navigationExtras.state = taskInfo;
      this.router.navigate([routerLink]);
    }
  }

  radioChangeHandler(e) {
    this.type = e;
    this.currPageInfo.offset = 0;
    this.setGroupByValue();
    this.setPage(this.currPageInfo);
    /*this.currPageInfo.offset = 0;
    this.taskFilters.shotIds = [];
    this.taskFilters.assetIds = [];    
    this.setPage(this.currPageInfo);*/
  }

  async getTableColumns() {
    await this.getTaskColumnList();
    if (this.tableColumns) {
      this.frameSelectedColumns();
      this.isDataReady = true;
    }
  }

  async getTaskColumnList() {
    await this.showsService
      .getTaskColumnList()
      .toPromise()
      .then((resp: any) => {
        if (resp && resp.entity && resp.entity.fields) {
          this.tableColumns = resp.entity.fields;
          if (!this.isReadOnly) {
            this.addEditableFlag(this.tableColumns);
          }
        }
      })
      .catch((error: any) => {
        this.tableColumns = null;
      });
  }

  addEditableFlag(tableColumns) {
    let nonEditableCols = [
      "shotCode",
      "taskName",
      "taskTypeName",
      "completionPercentage",
      "startDate",
      "endDate",
      "clientEta"
    ];
    tableColumns.map((item: any) => {
      item.isEditable = nonEditableCols.includes(item.name) ? false : true;
      return item;
    });
  }

  frameSelectedColumns() {
    this.selectedTableColumns = this.tableColumns.filter((item, index) => {
      item["index"] = index;
      if (item.name === "shotCode") {
        //item.defaultDisplay = true;
        //item.disabled = true;
      }
      return item.defaultDisplay;
    });
  }

  searchHandler() {
    this.isSearching = true;
  }

  searchDetails() {
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  searchBlur() {
    if (this.searchPattern == "") {
      this.isSearching = false;
    }
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  setGroupByValue() {
    this.groupBy = "";
    if (this.isRowGroupEnabled) {
      this.groupBy = this.type === "shot" ? "shotCode" : "assetName";
    } else {
    }
  }

  getGroupByValue() {
    return this.isRowGroupEnabled ? "shotCode" : "";
  }

  setPageSize() {
    let pageInfo = {
      pageSize: this.selectedPageSize,
      offset: 0
    };
    this.setPage(pageInfo);
  }

  getId(row: any) {
    return row.id;
  }

  setPage(pageInfo: any) {
    this.currPageInfo = pageInfo;
    this.isLoading = true;
    this.page.pageNumber = pageInfo.offset;
    this.page.size = pageInfo.pageSize;
    this.page.search = this.searchPattern;
    this.page.sortBy = this.sortBy;
    this.page.orderBy = this.orderBy;
    this.showDummy = true;
    let params = "";
    params = `&showId=${this.showId}&search=${this.page.search}&pageNo=${this.page.pageNumber}&pageSize=${this.page.size}&sortBy=${this.page.sortBy}&orderBy=${this.page.orderBy}`;
    if (this.shotId) {
      params += `&shotId=${this.shotId}`;
    } else if (this.assetId) {
      params += `&assetId=${this.assetId}`;
    }
    let filterParams = this.getFilterParams();

    if (filterParams !== "") {
      params += `&${filterParams}`;
    }
    let viewType = "ASSET_VIEW";
    if (this.type === "shot") {
      viewType = "SHOT_VIEW";
    }
    this.showsService.getTasksByView(this.page, params, viewType).subscribe(
      resp => {
        if (resp && resp.valid) {
          this.page.totalElements = resp.total;
          this.page.totalPages = Math.ceil(resp.total / this.page.size);
          this.rows = resp.coll;
          setTimeout(() => {
            this.isLoading = false;
            this.table.recalculate();
            try {
              let parentHeight = this.table.bodyComponent.scroller.parentElement.getBoundingClientRect()
                .height;
              let childHeight = this.table.bodyComponent.scroller.element.getBoundingClientRect()
                .height;
              if (childHeight > parentHeight) {
                this.showDummy = false;
              } else {
                this.showDummy = true;
              }
            } catch (e) {}
          }, 500);
        } else {
          this.rows = [];
        }

        this.setTableHeight();
      },
      error => {
        this.isLoading = false;
        this.rows = [];
        this.setTableHeight();
      }
    );
    /*if (this.assetId) {
      this.showsService.getTasksByAssetId(this.page, params).subscribe(
        resp => {
          if (resp && resp.valid) {
            this.page.totalElements = resp.total;
            this.page.totalPages = Math.ceil(resp.total / this.page.size);
            this.rows = resp.coll;
            setTimeout(() => {
              try {
                let parentHeight = this.table.bodyComponent.scroller.parentElement.getBoundingClientRect()
                  .height;
                let childHeight = this.table.bodyComponent.scroller.element.getBoundingClientRect()
                  .height;
                if (childHeight > parentHeight) {
                  this.showDummy = false;
                } else {
                  this.showDummy = true;
                }
              } catch (e) { }
            }, 500);
          } else {
            this.onDataError(resp);
          }
          this.isLoading = false;
        },
        error => {
          this.isLoading = false;
          this.onDataError(error);
        }
      );
    } else {
      this.showsService.getTasksByView(this.page, params, viewType).subscribe(
        //this.showsService.getTasksByShowAndShotIds(this.page, params).subscribe(
        resp => {
          if (resp && resp.valid) {
            this.page.totalElements = resp.total;
            this.page.totalPages = Math.ceil(resp.total / this.page.size);
            this.rows = resp.coll;
            setTimeout(() => {
              try {
                let parentHeight = this.table.bodyComponent.scroller.parentElement.getBoundingClientRect()
                  .height;
                let childHeight = this.table.bodyComponent.scroller.element.getBoundingClientRect()
                  .height;
                if (childHeight > parentHeight) {
                  this.showDummy = false;
                } else {
                  this.showDummy = true;
                }
              } catch (e) { }
            }, 500);
          } else {
            this.rows = [];
          }
          this.isLoading = false;
        },
        error => {
          this.isLoading = false;
          this.rows = [];
        }
      );
    }*/
  }

  getGroupHeader(group) {
    //console.log(group);
    return group.key;
    //return group.value[0].shotCode;
  }

  onDataReady() {}

  onDataError(error: any) {
    this.isEmptyData = true;
  }

  createTask() {
    this.drawerTitle = "Add Task";
    this.openTaskForm("create", this.taskInfo);
  }

  noteHandler(row: any) {
    this.drawerTitle = "Task Notes";
    this.openTaskNotes(row.id);
  }

  openTaskNotes(taskId: any): void {
    this.childDrawerRef = this.drawerService.create<
      NoteFormComponent,
      { taskId: any },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: NoteFormComponent,
      nzContentParams: {
        taskId: taskId
      },
      nzClosable: false,
      nzWidth: "50%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {});

    this.childDrawerRef.afterClose.subscribe(isSuccess => {});
  }

  async editHandler(row: any) {
    await this.getTask(row.id);
    if (this.taskOut) {
      this.drawerTitle = "Edit Task";
      this.openTaskForm("update", this.taskOut);
    }
  }

  async getTask(id: any) {
    this.taskOut = null;
    await this.showsService
      .getTask(id)
      .toPromise()
      .then(resp => {
        if (resp && resp.valid && resp.entity) {
          this.taskOut = resp.entity;
        }
      })
      .catch(error => {});
  }

  openTaskForm(mode: any, taskOut: any): void {
    this.childDrawerRef = this.drawerService.create<
      TaskFormComponent,
      {
        taskOut: any;
        mode: string;
        disableShowSelect?: boolean;
        showName?: any;
        type?: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: TaskFormComponent,
      nzContentParams: {
        taskOut: taskOut,
        mode: mode,
        disableShowSelect: true,
        showName: this.showName,
        type: this.type
      },
      nzClosable: false,
      nzWidth: "30%",
      nzWrapClassName: "modal-wrapper",
      nzOnCancel: () =>
        new Promise((resolve, reject) => {
          this.modalService.confirm({
            nzTitle: AppConstants.EXIT_WARNING_MESSAGE,
            nzOkText: "Yes",
            nzOkType: "default",
            nzOnOk: () => resolve(true),
            nzCancelText: "No",
            //nzCancelType: "primary",
            nzOnCancel: () => resolve(false)
          });
          return;
        })
    });

    this.childDrawerRef.afterOpen.subscribe(() => {});

    this.childDrawerRef.afterClose.subscribe(isSuccess => {
      if (isSuccess) {
        this.setPage(this.currPageInfo);
      }
    });
  }

  closeForm(): void {
    this.childDrawerRef.close();
  }

  deleteHandler(row: any) {
    this.isAlertVisible = true;
    this.taskToDelete = row;
  }

  deleteTaskConfirm = async () => {
    let successMessage = "Task has been successfully deleted.";
    let errorMessage = "Task deletion failed.";
    this.isAlertVisible = false;
    await this.showsService
      .deleteTask(this.taskToDelete.id)
      .toPromise()
      .then(resp => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: successMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
        this.setPage(this.currPageInfo);
      })
      .catch(error => {
        let errorDetails = this.helperService.getErrorDetails(error);
        if (errorDetails !== "") {
          errorMessage = `<b>${errorMessage}</b>` + errorDetails;
        }
        this.showNotification({
          type: "error",
          title: "Error",
          content: errorMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  };

  deleteTaskCancel = () => {
    this.isAlertVisible = false;
  };

  onShotNameClick(row) {
    let routerLink = this.router.url + "/" + row.shotId;
    this.router.navigate([routerLink]);
  }

  onDblClick(row, colId) {}

  toggleExpandGroup(group) {
    this.table.groupHeader.toggleExpandGroup(group);
  }

  onDetailToggle(event) {}

  clickHandler() {
    this.drawerTitle = "Table Columns";
    this.openColumnsSelectionForm();
  }

  filterHandler() {
    this.drawerTitle = "Filter Settings";
    this.openFilterSettingsForm();
  }

  openColumnsSelectionForm(): void {
    this.childDrawerRef = this.drawerService.create<
      TableColumnsSettingsComponent,
      {
        tableColumns: any;
        selectedTableColumns: any;
        type?: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: TableColumnsSettingsComponent,
      nzContentParams: {
        tableColumns: this.tableColumns,
        selectedTableColumns: this.selectedTableColumns,
        type: this.type
      },
      nzClosable: false,
      nzWidth: "40%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {});

    this.childDrawerRef.afterClose.subscribe(data => {
      if (data) {
        if (
          JSON.stringify(this.selectedTableColumns) !== JSON.stringify(data)
        ) {
          this.selectedTableColumns = data;
        } else {
        }
      }
    });
  }

  openFilterSettingsForm(): void {
    this.childDrawerRef = this.drawerService.create<
      ShotFilterSettingsComponent,
      {
        type: any;
        filters: any;
        showId: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: ShotFilterSettingsComponent,
      nzContentParams: {
        type: "task",
        filters: this.taskFilters,
        showId: this.showId
      },
      nzClosable: false,
      nzWidth: "40%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {});

    this.childDrawerRef.afterClose.subscribe(data => {
      if (data) {
        if (JSON.stringify(this.taskFilters) !== JSON.stringify(data)) {
          this.taskFilters = data;
          this.currPageInfo.offset = 0;
          this.setPage(this.currPageInfo);
        } else {
        }
      }
    });
  }

  getFilterParams() {
    let filterParams = "";
    /*if (this.shotFilters.seasonIds && this.shotFilters.seasonIds.length > 0) {
      if (filterParams != "") {
        filterParams += '&';
      }
      filterParams += `seasonId=${this.shotFilters.seasonIds[0]}`;
    }
    if (this.shotFilters.seasonIds && this.shotFilters.seasonIds.length > 0) {
      if (filterParams != "") {
        filterParams += '&';
      }
      filterParams += `seasonId=${this.shotFilters.seasonIds[0]}`;
    }*/
    for (let i in this.taskFilters) {
      let item = this.taskFilters[i];
      if (item && item.length > 0) {
        if (filterParams != "") {
          filterParams += "&";
        }
        filterParams += `${i}=${item.toString()}`;
      }
    }
    return filterParams;
  }

  onSelect({ selected }) {
    if (selected) {
      this.selected.splice(0, this.selected.length);
      this.selected.push(...selected);
    }
  }

  progressHandler() {
    let selectedIds = this.selected.map(item => {
      return item.id;
    });

    this.tasksService
      .getTaskProgressByTask(selectedIds)
      .toPromise()
      .then(resp => {
        this.isProgressVisible = true;
        if (resp && resp.entity) {
          this.taskProgress = Math.round(resp.entity);
        } else {
          this.taskProgress = 0;
        }
      })
      .catch(error => {});
  }

  onSort(event) {
    this.sortBy = event.sorts[0].prop;
    if (this.sortBy === "shotName") {
      return;
    }
    if (this.sortBy === "startDate") {
      this.sortBy = "projectedStartDt";
    }
    if (this.sortBy === "endDate") {
      this.sortBy = "projectedEndDt";
    }
    if (this.sortBy === "taskType") {
      this.sortBy = "taskTypeName";
    }
    if (this.sortBy === "artist") {
      this.sortBy = "artistName";
    }

    this.orderBy = event.sorts[0].dir.toUpperCase();
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  getColWidth(colName) {
    if (
      colName === "artistName" ||
      colName === "accountableName" ||
      colName === "workStatus" ||
      colName === "sequenceName"
    ) {
      return 200;
    } else if (
      colName === "shotName" ||
      colName === "taskName" ||
      colName === "completionPercentage" ||
      colName === "annotationPath" ||
      colName === "referencePath" ||
      colName === "description"
    ) {
      return 250;
    } else if (colName === "thumbnail") {
      return 150;
    } else {
      return 200;
    }
  }

  getWorkStatusColorCode(row: any) {
    let defaultCode = "#038e4e";
    let matched = this.helperService.findObjectInArrayByKey(
      this.workStatuses,
      "id",
      row.workStatusId
    );
    return matched && matched.code ? matched.code : defaultCode;
  }

  getTaskTypeColorCode(row: any) {
    let defaultCode = "#fff";
    return row && row.taskColorCode ? row.taskColorCode : defaultCode;
  }

  enableEdit(row: any, col: any) {
    this.resetEditFlags();
    this.editing[row.id + "-" + col.name] = true;
  }

  resetEditFlags() {
    for (let key in this.editing) {
      if (this.editing.hasOwnProperty(key)) {
        this.editing[key] = false;
      }
    }
  }

  showNotification(info: any) {
    this.notificationService.showNotification(info);
  }

  dateOpenChange(row: any, col: any, isOpen: any) {
    if (!isOpen) {
      this.editing[row.id + "-" + col.name] = false;
    }
  }

  disabledOldDates = (startValue: Date): boolean => {
    if (!startValue) {
      return false;
    }
    let today = new Date();
    let yesterday = new Date(today.setDate(today.getDate() - 1));
    return startValue.getTime() < yesterday.getTime();
  };

  inlineEditHandler(row: any, col: any) {
    this.resetEditFlags();
    this.myrow = row;
    this.mycol = col;

    //this.isSequenceSelect = false;
    //this.isStatusSelect = false;
    this.isSupervisorSelect = false;
    this.modalTitle = "";

    if (col.name === "artistName") {
      this.modalTitle = "Edit Artist";
      this.selectedArtistId = row.artistId;
      this.isArtistSelect = true;
      this.getArtists();
    } else if (col.name === "accountableName") {
      this.modalTitle = "Edit Accountable";
      this.selectedSupervisorId = row.accountable;
      this.isSupervisorSelect = true;
      this.getSupervisors();
    } else if (col.name === "priority") {
      this.modalTitle = "Edit Priority";
      this.selectedPriorityId = row.taskPriorityId;
      this.isPrioritySelect = true;
      this.getTaskPriorities();
    } else if (col.name === "workStatus") {
      this.modalTitle = "Edit Work Status";
      this.selectedWorkStatusId = row.workStatusId;
      this.isWorkStatusSelect = true;
      this.getWorkstatusList();
    }
    if (this.modalTitle !== "") {
      this.showModal();
    }
  }

  async inlineEditConfirm(row: any, col: any) {
    let shotId = row.id;
    let shotIn: any;
    this.isVisible = false;
    if (col.name === "artistName") {
      this.isArtistSelect = false;
      if (this.selectedArtistId !== row.artistId) {
        shotIn = {
          type: "artistId",
          artistId: row.artistId
        };
        await this.updateConfirm(row, col, shotId, shotIn);
        if (this.isEditSuccess) {
          row[col.name] = this.getArtistNameById(row.artistId);
        }
      }
    } else if (col.name === "accountableName") {
      this.isSupervisorSelect = false;
      if (this.selectedSupervisorId !== row.accountable) {
        shotIn = {
          type: "accountable",
          accountable: row.accountable
        };
        await this.updateConfirm(row, col, shotId, shotIn);
        if (this.isEditSuccess) {
          row[col.name] = this.getSupervisorNameById(row.accountable);
        }
      }
    } else if (col.name === "priority") {
      this.isPrioritySelect = false;
      if (this.selectedPriorityId !== row.taskPriorityId) {
        shotIn = {
          type: "taskPriorityId",
          taskPriorityId: row.taskPriorityId
        };
        await this.updateConfirm(row, col, shotId, shotIn);
        if (this.isEditSuccess) {
          row[col.name] = this.getPriorityNameById(row.taskPriorityId);
        }
      }
    } else if (col.name === "workStatus") {
      this.isWorkStatusSelect = false;
      if (this.selectedWorkStatusId !== row.workStatusId) {
        shotIn = {
          type: "workStatusId",
          workStatusId: row.workStatusId
        };
        await this.updateConfirm(row, col, shotId, shotIn);
        if (this.isEditSuccess) {
          row[col.name] = this.getWorkStatusNameById(row.workStatusId);
        }
      }
    }
  }

  inlineEditCancel(row: any, col: any) {
    this.isVisible = false;
    if (col.name === "artistName") {
      this.isArtistSelect = false;
      row.artistId = this.selectedArtistId;
    } else if (col.name === "accountableName") {
      this.isSupervisorSelect = false;
      row.accountable = this.selectedSupervisorId;
    } else if (col.name === "priority") {
      this.isPrioritySelect = false;
      row.taskPriorityId = this.selectedPriorityId;
    } else if (col.name === "workStatus") {
      this.isWorkStatusSelect = false;
      row.workStatusId = this.selectedWorkStatusId;
    }
  }

  getArtistNameById(id: any) {
    let matched = this.helperService.findObjectInArrayByKey(
      this.artists,
      "id",
      id
    );
    if (matched) {
      return matched.title;
    } else {
      return "";
    }
  }

  getSupervisorNameById(id: any) {
    let matched = this.helperService.findObjectInArrayByKey(
      this.supervisors,
      "id",
      id
    );
    if (matched) {
      return matched.title;
    } else {
      return "";
    }
  }

  getPriorityNameById(id: any) {
    let matched = this.helperService.findObjectInArrayByKey(
      this.taskPriorities,
      "id",
      id
    );
    if (matched) {
      return matched.taskPriorityLevel;
    } else {
      return "";
    }
  }

  getWorkStatusNameById(id: any) {
    let matched = this.helperService.findObjectInArrayByKey(
      this.workStatuses,
      "id",
      id
    );
    if (matched) {
      return matched.name;
    } else {
      return "";
    }
  }

  showModal(): void {
    this.isVisible = true;
  }

  isValidArr(arr: any) {
    return this.helperService.isValidArr(arr);
  }

  isEndDateDisabled(row) {
    let startValue = row["startDate"].value; // this.dataForm.controls.startDate.value;
    if (!startValue) {
      return true;
    }
    return false;
  }

  /*disabledEndDate = (endValue: Date, row: any): boolean => {
    console.log(endValue + ' : ' + row['startDate']);
    let startValue = row['startDate'].value;
    if (!endValue || !startValue) {
      return false;
    }
    return endValue.getTime() < startValue.getTime();
  };*/

  async updateDateValue(row: any, col: any, event: any) {
    let prev = null;
    if (row[col.name]) {
      prev = this.helperService.transformDate(row[col.name]);
    }
    let format = "yyyy-MM-dd 23:59:59";
    if (col.name === "startDate") {
      format = "yyyy-MM-dd 00:00:00";
    }
    let curr = this.helperService.transformDate(event, format);
    if (prev != curr) {
      let taskId = row.id;
      let taskIn = {
        type: col.name
      };
      taskIn[col.name] = curr;
      await this.updateConfirm(row, col, taskId, taskIn);
    }
    if (this.isEditSuccess) {
      row[col.name] = event;
    }
  }

  async updateValue(row: any, col: any, event: any) {
    if (row[col.name] != event.target.value) {
      let taskId = row.id;
      let taskIn = {
        type: col.name
      };
      taskIn[col.name] = event.target.value;
      await this.updateConfirm(row, col, taskId, taskIn);
    }
    if (this.isEditSuccess) {
      row[col.name] = event.target.value;
    }
    this.editing[row.id + "-" + col.name] = false;
  }

  async updateConfirm(row: any, col: any, taskId: any, taskIn: any) {
    this.isEditSuccess = false;
    let errorMessage = "Record update failed.";
    await this.showsService
      .inlineEditTask(taskId, taskIn)
      .toPromise()
      .then((resp: any) => {
        this.isEditSuccess = true;
      })
      .catch((error: any) => {
        let errorDetails = this.helperService.getErrorDetails(error);
        if (errorDetails !== "") {
          errorMessage = `<b>${errorMessage}</b>` + errorDetails;
        }
        this.isEditSuccess = false;
      });
    if (this.isEditSuccess) {
      this.showNotification({
        type: "success",
        title: "Success",
        content: "Record updated successfully.",
        duration: AppConstants.NOTIFICATION_DURATION
      });
    } else {
      this.showNotification({
        type: "error",
        title: "Error",
        content: errorMessage,
        duration: AppConstants.NOTIFICATION_DURATION
      });
    }
  }

  getTitle(row: any, col: any) {
    return row[col.name];
  }

  async getSupervisors() {
    await this.showsService
      .getSupervisorsByShowId(this.showId)
      .toPromise()
      .then((resp: any) => {
        this.supervisors = resp.entity;
      })
      .catch((error: any) => {
        this.supervisors = [];
      });
  }

  async getArtists() {
    await this.showsService
      .getArtistsByShowId(this.showId)
      .toPromise()
      .then((resp: any) => {
        this.artists = resp.entity;
      })
      .catch((error: any) => {
        this.artists = [];
      });
  }

  async getTaskPriorities() {
    await this.showsService
      .getTaskPriorities()
      .toPromise()
      .then((resp: any) => {
        this.taskPriorities = resp.entity;
      })
      .catch((error: any) => {
        this.taskPriorities = [];
      });
  }

  async getWorkstatusList() {
    await this.workstatusService
      .getWorkstatusList()
      .toPromise()
      .then((resp: any) => {
        this.workStatuses = resp.entity;
      })
      .catch((error: any) => {
        this.workStatuses = [];
      });
  }

  setTableHeight() {
    if (!this.isValidArr(this.rows)) {
      this.tableHeight = 150 + "px";
    } else {
      if (this.rows.length <= 10) {
        this.tableHeight = this.rows.length * 50 + 120 + "px";
        if (this.isRowGroupEnabled) {
          //this.tableHeight = this.rows.length * 60 + 120 + "px";
          this.tableHeight = "calc(100vh - 200px)";
        }
      } else {
        this.tableHeight = "calc(100vh - 300px)";
      }
    }
  }

  getTableHeight() {
    return this.tableHeight;
  }
}
