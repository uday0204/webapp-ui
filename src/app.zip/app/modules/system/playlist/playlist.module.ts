import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PlaylistRoutingModule } from './playlist-routing.module';
import { PlaylistHomeComponent } from './playlist-home/playlist-home.component';
import { SharedModule } from '../../shared/shared.module';


@NgModule({
  declarations: [PlaylistHomeComponent],
  imports: [
    CommonModule,
    PlaylistRoutingModule,
    SharedModule
  ]
})
export class PlaylistModule { }
