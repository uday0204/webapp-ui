import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpService } from '../core/services/http.service';
import { LoggerService } from '../core/services/logger.service';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */

  constructor(private http: HttpService, private logger: LoggerService) { }

  getAddMenu() {
    let endPoint = this.apiUrl + 'action/addmenu';
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "action-addmenu";
    }
    this.logger.log("HomeService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getListMenu() {
    let endPoint = this.apiUrl + 'action/menu';
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "action-menu";
    }
    this.logger.log("HomeService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }




}
