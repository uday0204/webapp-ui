import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ArtistTaskListComponent } from './artist-task-list/artist-task-list.component';


const routes: Routes = [
  { path: "", component: ArtistTaskListComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TasksRoutingModule { }
