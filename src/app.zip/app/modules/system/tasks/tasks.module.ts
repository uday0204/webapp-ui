import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TasksRoutingModule } from './tasks-routing.module';
import { ArtistTaskListComponent } from './artist-task-list/artist-task-list.component';
import { SharedModule } from '../../shared/shared.module';


@NgModule({
  declarations: [ArtistTaskListComponent],
  imports: [
    CommonModule,
    TasksRoutingModule,
    SharedModule
  ]
})
export class TasksModule { }
