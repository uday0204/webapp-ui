import {
  Component,
  OnInit,
  TemplateRef,
  ViewChild,
  AfterViewInit
} from "@angular/core";
import { FormGroup, Validators, FormBuilder } from "@angular/forms";
import { InteractionService } from "src/app/modules/core/services/interaction.service";
import { SystemSettingsService } from "../system-settings.service";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { AppConstants } from "src/app/constants/AppConstants";
import { NotificationService } from "src/app/modules/core/services/notification.service";

@Component({
  selector: "app-settings-tab",
  templateUrl: "./settings-tab.component.html",
  styleUrls: ["./settings-tab.component.scss"]
})
export class SettingsTabComponent implements OnInit {
  @ViewChild("display", { static: false }) displayTemplate: TemplateRef<{}>;
  @ViewChild("authentication", { static: false }) authTemplate: TemplateRef<{}>;
  @ViewChild("email", { static: false }) emailTemplate: TemplateRef<{}>;
  @ViewChild("storage", { static: false }) storageTemplate: TemplateRef<{}>;

  isDataReady: boolean = false;
  displayForm: FormGroup;
  authenticationForm: FormGroup;
  mailForm: FormGroup;
  storageForm: FormGroup;
  tabDetails: any;
  configData: any;
  displaySettings: any;
  authSettings: any;
  mailSettings: any;
  storageSettings: any;

  constructor(
    private interactionService: InteractionService,
    private fb: FormBuilder,
    private systemSettingsService: SystemSettingsService,
    private helperService: HelperService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.interactionService.sendInteraction("breadcrumb", "System Settings");
    this.helperService.isGlobalAddEnabled = true;
    this.prepareData();
  }

  getDataByConfigKeyCode(key: any) {
    return this.helperService.findObjectInArrayByKey(
      this.configData,
      "configKeyCode",
      key
    );
  }

  async prepareData() {
    await this.getConfigData();
    this.displaySettings = {
      lang: this.getDataByConfigKeyCode("LANG"),
      weekStart: this.getDataByConfigKeyCode("WEEK_START"),
      dateFormat: this.getDataByConfigKeyCode("DATE_FORMAT"),
      timeFormat: this.getDataByConfigKeyCode("TIME_FORMAT")
    };

    this.authSettings = {
      emailExpiry: this.getDataByConfigKeyCode("EMAIL_EXPIRY"),
      loginAttempt: this.getDataByConfigKeyCode("MAX_LOGIN_ATTEMPT"),
      sessionExpiry: this.getDataByConfigKeyCode("SESSION_EXPIRY")
    };

    this.mailSettings = {
      server: this.getDataByConfigKeyCode("SMTP_SERVER"),
      port: this.getDataByConfigKeyCode("SMTP_PORT"),
      domain: this.getDataByConfigKeyCode("SMTP_DOMAIN"),
      authentication: this.getDataByConfigKeyCode("SMTP_AUTH"),
      username: this.getDataByConfigKeyCode("SMTP_USER"),
      password: this.getDataByConfigKeyCode("SMTP_PASSWORD")
    };

    this.storageSettings = {
      username: this.getDataByConfigKeyCode("STORAGE_USERNAME"),
      password: this.getDataByConfigKeyCode("STORAGE_PASSWORD"),
      serverPath: this.getDataByConfigKeyCode("STORAGE_PATH")
    };

    this.buildFormInfo();
    this.buildTabInfo();
    this.isDataReady = true;
  }

  async getConfigData() {
    await this.systemSettingsService
      .getConfig()
      .toPromise()
      .then((resp: any) => {
        this.configData = resp.entity;
      })
      .catch((error: any) => {
        this.configData = [];
      });
  }

  buildFormInfo() {
    this.displayForm = this.fb.group({
      lang: [
        this.getSettingsValue(this.displaySettings, "lang"),
        [Validators.required]
      ],
      weekStart: [
        this.getSettingsValue(this.displaySettings, "weekStart"),
        [Validators.required]
      ],
      dateFormat: [
        this.getSettingsValue(this.displaySettings, "dateFormat"),
        [Validators.required]
      ],
      timeFormat: [
        this.getSettingsValue(this.displaySettings, "timeFormat"),
        [Validators.required]
      ]
    });

    this.authenticationForm = this.fb.group({
      emailExpiry: [
        this.getSettingsValue(this.authSettings, "emailExpiry"),
        [Validators.required]
      ],
      loginAttempt: [
        this.getSettingsValue(this.authSettings, "loginAttempt"),
        [Validators.required]
      ],
      sessionExpiry: [
        this.getSettingsValue(this.authSettings, "sessionExpiry"),
        [Validators.required]
      ]
    });

    this.mailForm = this.fb.group({
      server: [
        this.getSettingsValue(this.mailSettings, "server", "text"),
        [Validators.required]
      ],
      port: [
        this.getSettingsValue(this.mailSettings, "port", "text"),
        [Validators.required]
      ],
      domain: [
        this.getSettingsValue(this.mailSettings, "domain", "text"),
        [Validators.required]
      ],
      authentication: [
        this.getSettingsValue(this.mailSettings, "authentication", "text"),
        [Validators.required]
      ],
      username: [
        this.getSettingsValue(this.mailSettings, "username", "text"),
        [Validators.required]
      ],
      password: [
        this.getSettingsValue(this.mailSettings, "password", "text"),
        [Validators.required]
      ]
    });

    this.storageForm = this.fb.group({
      username: [
        this.getSettingsValue(this.storageSettings, "username", "text"),
        [Validators.required]
      ],
      password: [
        this.getSettingsValue(this.storageSettings, "password", "text"),
        [Validators.required]
      ],
      serverPath: [
        this.getSettingsValue(this.storageSettings, "serverPath", "text"),
        [Validators.required]
      ]
    });
  }

  getSettingsValue(setting: any, key: any, type?: any) {
    if (
      setting &&
      setting[key] &&
      setting[key].settings &&
      setting[key].settings.configKeyValue
    ) {
      if (type && type === "text") {
        return setting[key].settings.configKeyValue;
      } else {
        return Number(setting[key].settings.configKeyValue);
      }
    }
    return null;
  }

  buildTabInfo() {
    this.tabDetails = [
      {
        id: "display",
        tabIcon: "desktop_windows",
        tabTitle: "Display",
        tabContentTitle: "Display Settings"
      },
      {
        id: "auth",
        tabIcon: "security",
        tabTitle: "Authentication",
        tabContentTitle: "Authentication Settings"
      },
      {
        id: "email",
        tabIcon: "email",
        tabTitle: "Email",
        tabContentTitle: "Email Settings"
      },
      {
        id: "storage",
        tabIcon: "account_circle",
        tabTitle: "Storage Authentication",
        tabContentTitle: "Storage Authentication Settings"
      }
    ];
  }

  getTabContentTemplate(id: any) {
    return this[id + "Template"];
  }

  showNotification(info: any) {
    this.notificationService.showNotification(info);
  }

  async submitDisplayForm() {
    for (const i in this.displayForm.controls) {
      this.displayForm.controls[i].markAsDirty();
      this.displayForm.controls[i].updateValueAndValidity();
    }
    console.log(this.displayForm.value);
    if (!this.displayForm.valid) {
      return;
    }
    let postObj = {
      settings: []
    };
    for (let i in this.displayForm.value) {
      let arr = this.displaySettings[i].values;
      let value = this.displayForm.value[i];
      let obj = this.helperService.findObjectInArrayByKey(arr, "id", value);
      let settings = {};
      if (this.displaySettings[i].settings) {
        settings = this.displaySettings[i].settings;
      }
      settings["configKeyId"] = obj.configKeyId;
      settings["configKeyValue"] = String(obj.id);
      postObj.settings.push(settings);
    }
    await this.systemSettingsService
      .addSettings(postObj)
      .toPromise()
      .then((resp: any) => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: "Settings has been successfully updated.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      })
      .catch((error: any) => {
        this.showNotification({
          type: "error",
          title: "Error",
          content: "Settings updation failed.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  }
  async submitAuthenticationForm() {
    for (const i in this.authenticationForm.controls) {
      this.authenticationForm.controls[i].markAsDirty();
      this.authenticationForm.controls[i].updateValueAndValidity();
    }
    console.log(this.authenticationForm.value);
    if (!this.authenticationForm.valid) {
      return;
    }
    let postObj = {
      settings: []
    };
    for (let i in this.authenticationForm.value) {
      let arr = this.authSettings[i].values;
      let value = this.authenticationForm.value[i];
      let obj = this.helperService.findObjectInArrayByKey(arr, "id", value);
      let settings = {};
      if (this.authSettings[i].settings) {
        settings = this.authSettings[i].settings;
      }
      settings["configKeyId"] = obj.configKeyId;
      settings["configKeyValue"] = String(obj.id);
      postObj.settings.push(settings);
    }
    await this.systemSettingsService
      .addSettings(postObj)
      .toPromise()
      .then((resp: any) => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: "Settings has been successfully updated.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      })
      .catch((error: any) => {
        this.showNotification({
          type: "error",
          title: "Error",
          content: "Settings updation failed.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  }

  async submitMailForm() {
    for (const i in this.mailForm.controls) {
      this.mailForm.controls[i].markAsDirty();
      this.mailForm.controls[i].updateValueAndValidity();
    }
    console.log(this.mailForm.value);
    if (!this.mailForm.valid) {
      return;
    }
    let postObj = {
      settings: []
    };
    for (let i in this.mailForm.value) {
      let settings = {};
      if (this.mailSettings[i].settings) {
        settings = this.mailSettings[i].settings;
      }
      settings["configKeyId"] = this.mailSettings[i].id;
      settings["configKeyValue"] = this.mailForm.value[i];
      postObj.settings.push(settings);
    }
    await this.systemSettingsService
      .addSettings(postObj)
      .toPromise()
      .then((resp: any) => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: "Settings has been successfully updated.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      })
      .catch((error: any) => {
        this.showNotification({
          type: "error",
          title: "Error",
          content: "Settings updation failed.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  }

  async submitStorageForm() {
    for (const i in this.storageForm.controls) {
      this.storageForm.controls[i].markAsDirty();
      this.storageForm.controls[i].updateValueAndValidity();
    }
    console.log(this.storageForm.value);
    if (!this.storageForm.valid) {
      return;
    }
    let postObj = {
      settings: []
    };

    for (let i in this.storageForm.value) {
      let settings = {};
      if (this.storageSettings[i].settings) {
        settings = this.storageSettings[i].settings;
      }
      settings["configKeyId"] = this.storageSettings[i].id;
      settings["configKeyValue"] = this.storageForm.value[i];
      postObj.settings.push(settings);
    }

    await this.systemSettingsService
      .addSettings(postObj)
      .toPromise()
      .then((resp: any) => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: "Settings has been successfully updated.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      })
      .catch((error: any) => {
        this.showNotification({
          type: "error",
          title: "Error",
          content: "Settings updation failed.",
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  }
}
