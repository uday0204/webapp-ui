import { Injectable } from '@angular/core';
import { HttpService } from "../../core/services/http.service";
import { LoggerService } from "../../core/services/logger.service";
import { environment } from "src/environments/environment";
import { AppConstants } from "src/app/constants/AppConstants";

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */

  constructor(private http: HttpService, private logger: LoggerService) { }

  /** Client APIs START */

  createClient(clientIn: any) {
    const endPoint = this.apiUrl + AppConstants.CLIENT;
    this.logger.log("ClientService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, clientIn);
  }

  getClient(id: any) {
    let endPoint = this.apiUrl + AppConstants.CLIENT + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "client";
    }
    this.logger.log("ClientService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  updateClient(clientIn: any) {
    const endPoint = this.apiUrl + AppConstants.CLIENT + "/" + clientIn.id;
    this.logger.log("ClientService Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, clientIn);
  }

  deleteClient(id: any) {
    const endPoint = this.apiUrl + AppConstants.CLIENT + "/" + id + '/delete';
    this.logger.log("ClientService Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, null);
  }

  getClientList() {
    let endPoint = this.apiUrl + AppConstants.CLIENT;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "list-client";
    }
    this.logger.log("ClientService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getClientTableList(page: any) {
    let params = ``;
    if (page) {
      params += `search=${page.search}&pageNo=${page.pageNumber}&pageSize=${page.size}&sortBy=${page.sortBy}&orderBy=${page.orderBy}`;
    }
    let endPoint = this.apiUrl + AppConstants.CLIENT_SEARCH + "/?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "client-list-table";
    }
    this.logger.log("ClientService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  toggleActivate(id: any) {
    const endPoint = this.apiUrl + AppConstants.CLIENT + "/" + id + '/toggle-activate';
    this.logger.log("ClientService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** Client APIs END */

}
