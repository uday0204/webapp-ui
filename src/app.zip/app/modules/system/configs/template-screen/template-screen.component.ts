import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-screen',
  templateUrl: './template-screen.component.html',
  styleUrls: ['./template-screen.component.scss']
})
export class TemplateScreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
