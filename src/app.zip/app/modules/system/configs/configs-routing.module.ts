import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TaskTypeListComponent } from './task-type-list/task-type-list.component';
import { WorkStatusListComponent } from './work-status-list/work-status-list.component';
import { PriorityListComponent } from './priority-list/priority-list.component';
import { ClientListComponent } from './client-list/client-list.component';
import { GroupListComponent } from './group-list/group-list.component';
import { DepartmentListComponent } from './department-list/department-list.component';
import { TemplateScreenComponent } from './template-screen/template-screen.component';
import { SettingsTabComponent } from './settings-tab/settings-tab.component';
import { UserListComponent } from './user-list/user-list.component';
import { MyRoleListComponent } from './my-role-list/my-role-list.component';
import { AuthGuard } from '../../core/authentication/auth.guard';
import { Role } from '../../shared/model/role';

const rolesAllowed = [Role.ADMIN];
const routes: Routes = [
  { path: "users", component: UserListComponent, canActivate: [AuthGuard], data: { permission: 'User' } },
  { path: "clients", component: ClientListComponent, canActivate: [AuthGuard], data: { permission: 'Client' } },
  { path: "priorities", component: PriorityListComponent, canActivate: [AuthGuard], data: { permission: 'Priority' } },
  { path: "workstatus", component: WorkStatusListComponent, canActivate: [AuthGuard], data: { permission: 'Work Status' } },
  { path: "tasktypes", component: TaskTypeListComponent, canActivate: [AuthGuard], data: { permission: 'Task Type' } },
  { path: "departments", component: DepartmentListComponent, canActivate: [AuthGuard], data: { permission: 'Department' } },
  { path: "groups", component: GroupListComponent, canActivate: [AuthGuard], data: { permission: 'Group' } },
  { path: "templates", component: TemplateScreenComponent, canActivate: [AuthGuard], data: { permission: 'Template' } },
  { path: "roles", component: MyRoleListComponent, canActivate: [AuthGuard], data: { permission: 'Role' } },
  { path: "settings", component: SettingsTabComponent, canActivate: [AuthGuard], data: { roles: rolesAllowed } },
  { path: "", redirectTo: "/system/listing/configs/users", pathMatch: "full" },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigsRoutingModule { }
