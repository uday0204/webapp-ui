import { Component, OnInit, ViewChild, TemplateRef, ViewEncapsulation } from "@angular/core";
import { ArtistDbSettingsComponent } from "../../modals/artist-db-settings/artist-db-settings.component";
import { NzDrawerService } from "ng-zorro-antd";
import { WorkstatusService } from '../../configs/workstatus.service';
import { HelperService } from 'src/app/modules/core/services/helper.service';
import { ArtistDashboardComponent } from '../artist-dashboard/artist-dashboard.component';
import { KanbanComponent } from 'src/app/modules/shared/components/kanban/kanban.component';

@Component({
  selector: "app-artist-dashboard-home",
  templateUrl: "./artist-dashboard-home.component.html",
  styleUrls: ["./artist-dashboard-home.component.scss"],
  encapsulation: ViewEncapsulation.None
})
export class ArtistDashboardHomeComponent implements OnInit {
  @ViewChild("drawerHeader", { static: false }) drawerHeader: TemplateRef<{}>;
  @ViewChild(ArtistDashboardComponent, { static: false }) artistDashboardComponent: ArtistDashboardComponent;
  //@ViewChild('kanbanChart', { static: false }) kanbanChart: KanbanComponent;
  @ViewChild(KanbanComponent, { static: false }) kanbanChart: KanbanComponent;

  title = 'jkanban';

  isDashboardVisible: boolean;
  isKanbanVisible: boolean;
  drawerTitle: any;
  childDrawerRef: any;
  workStatuses: any;
  overallSelectedItems: any;
  starSelectedItems: any;

  constructor(
    private drawerService: NzDrawerService,
    private workstatusService: WorkstatusService,
    private helperService: HelperService
  ) { }

  ngOnInit() {
    this.drawerTitle = "Artist Dashboard Settings";
    this.showDashboard();
    //this.showKanban();
    this.getWorkstatusList();
  }

  async getWorkstatusList() {
    await this.workstatusService
      .getWorkstatusList()
      .toPromise()
      .then((resp: any) => {
        this.workStatuses = resp.entity;
        this.overallSelectedItems = this.workStatuses.slice(0, 5);
        this.starSelectedItems = this.workStatuses.slice(0, 4);
      })
      .catch((error: any) => {
        this.workStatuses = [];
      });
  }

  showDashboard() {
    this.isDashboardVisible = true;
    this.isKanbanVisible = false;
  }
  showKanban() {
    this.isDashboardVisible = false;
    this.isKanbanVisible = true;
  }

  showSettings() {
    this.openDashboardSettings();
  }

  isValidArr(arr: any) {
    return this.helperService.isValidArr(arr);
  }

  closeForm(): void {
    this.childDrawerRef.close();
  }


  openDashboardSettings(): void {
    this.childDrawerRef = this.drawerService.create<
      ArtistDbSettingsComponent,
      {
        workStatuses: any;
        overallSelectedItems: any;
        starSelectedItems: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: ArtistDbSettingsComponent,
      nzContentParams: {
        workStatuses: this.workStatuses,
        overallSelectedItems: this.overallSelectedItems,
        starSelectedItems: this.starSelectedItems,
      },
      nzClosable: false,
      nzWidth: "40%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("childDrawerRef Drawer(Component) open");
    });

    this.childDrawerRef.afterClose.subscribe(data => {
      if (data) {
        let result = JSON.parse(data);
        if (!this.helperService.isSameObject(this.overallSelectedItems, result.overallSelectedItems)) {
          this.overallSelectedItems = result.overallSelectedItems;
          this.artistDashboardComponent.updateOverallStatus(this.overallSelectedItems);
        }
        if (!this.helperService.isSameObject(this.starSelectedItems, result.starSelectedItems)) {
          this.starSelectedItems = result.starSelectedItems;
          this.artistDashboardComponent.updateStarStatus(this.starSelectedItems);
        }
      }
    });
  }
}
