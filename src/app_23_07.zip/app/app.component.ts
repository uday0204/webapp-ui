import { Component } from '@angular/core';
import { Router } from "@angular/router";
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  {
  isCollapsed = false;
  constructor(
    
    private router: Router,
   
  ) {}
  getAvatarInfo() {
    let user = {
      firstName: "U",
      lastName: "N",
      thumbnail: "",
    };
    
    

    return {
      ...user,
      size: "large",
    };
  }
  logoutHandler() {
    this.router.navigate(["/login"]);
  }
}
