import { Injectable } from "@angular/core";
import { AppConstants } from "src/app/constants/AppConstants";
import { environment } from "src/environments/environment";
import { HttpService } from "../../core/services/http.service";
import { LoggerService } from "../../core/services/logger.service";

@Injectable({
  providedIn: "root"
})
export class PlaylistService {
  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */

  constructor(private http: HttpService, private logger: LoggerService) {}

  getDailiesPlaylist(params: any) {
    let endPoint = this.apiUrl + AppConstants.PLAYLIST_DAILIES + "?" + params;
    this.isLocal = true;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "playlist-dailies" + "?" + params;
    }
    this.logger.log("PlaylistService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }
}
