import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { SystemRoutingModule } from "./system-routing.module";
import { NgZorroAntdModule, NZ_I18N, en_US } from "ng-zorro-antd";

import { HomeComponent } from "./home/home.component";
import { ListingComponent } from "./listing/listing.component";
import { HelpComponent } from "./help/help.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SettingsComponent } from "./settings/settings.component";
 import { NgxDatatableModule } from "@swimlane/ngx-datatable";
 import { SharedModule } from "../shared/shared.module";
  
@NgModule({
  declarations: [
    HomeComponent,
    ListingComponent,
    HelpComponent,
    SettingsComponent, 
  ],
  imports: [
    CommonModule,
    SystemRoutingModule,
    NgZorroAntdModule,
    FormsModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    SharedModule
  ],
  providers: [{ provide: NZ_I18N, useValue: en_US }]
})
export class SystemModule { }
