import { Injectable } from '@angular/core';
import { HttpService } from "../../core/services/http.service";
import { LoggerService } from "../../core/services/logger.service";
import { environment } from "src/environments/environment";
import { AppConstants } from "src/app/constants/AppConstants";

@Injectable({
  providedIn: 'root'
})
export class DepartmentsService {

  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */

  constructor(private http: HttpService, private logger: LoggerService) { }

  /** Department APIs START */

  createDepartment(departmentIn: any) {
    const endPoint = this.apiUrl + AppConstants.DEPARTMENT;
    this.logger.log("DepartmentsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, departmentIn);
  }

  getDepartment(id: any) {
    let endPoint = this.apiUrl + AppConstants.DEPARTMENT + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "department";
    }
    this.logger.log("DepartmentsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  updateDepartment(departmentIn: any) {
    const endPoint = this.apiUrl + AppConstants.DEPARTMENT + "/" + departmentIn.id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, departmentIn);
  }

  deleteDepartment(id: any) {
    const endPoint = this.apiUrl + AppConstants.DEPARTMENT + "/" + id + '/delete';
    this.logger.log("DepartmentsService Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, null);
  }

  getDepartmentTableList(page: any) {
    let params = ``;
    if (page) {
      params += `search=${page.search}&pageNo=${page.pageNumber}&pageSize=${page.size}&sortBy=${page.sortBy}&orderBy=${page.orderBy}`;
    }
    let endPoint = this.apiUrl + AppConstants.DEPARTMENT_SEARCH + "/?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "department-list-table";
    }
    this.logger.log("DepartmentsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getDepartmentList() {
    let endPoint = this.apiUrl + AppConstants.DEPARTMENT_LIST;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "department-list";
    }
    this.logger.log("DepartmentsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getDepartmentListSearch() {
    let endPoint = this.apiUrl + AppConstants.DEPARTMENT_LIST_SEARCH + '?search=';
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "department-list-search";
    }
    this.logger.log("DepartmentsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  inlineEdit(id: any, groupIn: any) {
    const endPoint = this.apiUrl + AppConstants.DEPARTMENT_INLINE_EDIT + "/" + id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.patch<any>(endPoint, groupIn);
  }

  toggleActivate(id: any) {
    const endPoint = this.apiUrl + AppConstants.DEPARTMENT + "/" + id + '/toggle-activate';
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** Department APIs END */
}
