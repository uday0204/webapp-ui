import { Component, OnInit, ViewChild, TemplateRef } from "@angular/core";
import { Router } from "@angular/router";
import { ActivatedRoute } from "@angular/router";
import { LoggerService } from "src/app/modules/core/services/logger.service";
import { ShowsService } from "../shows.service";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { NzDrawerService, NzModalService } from "ng-zorro-antd";
import { ShowFormComponent } from "../../modals/show-form/show-form.component";
import { InteractionService } from "src/app/modules/core/services/interaction.service";
import { NotificationService } from "src/app/modules/core/services/notification.service";
import { AppConstants } from "src/app/constants/AppConstants";
import { BackupFormComponent } from "../../modals/backup-form/backup-form.component";

@Component({
  selector: "app-show-detail",
  templateUrl: "./show-detail.component.html",
  styleUrls: ["./show-detail.component.scss"]
})
export class ShowDetailComponent implements OnInit {
  @ViewChild("drawerHeader", { static: false }) drawerHeader: TemplateRef<{}>;
  childDrawerRef: any;
  isDataReady: boolean;
  isEmptyData: boolean;
  showId: any;
  showIn: any;
  showOut: any;
  showStatus: any;
  overviewPanel = {
    active: true,
    disabled: false,
    name: "Show Overview",
    customStyle: {
      //background: '#212121',
      "border-radius": "4px",
      "margin-bottom": "8px",
      border: "0px"
    }
  };
  cardData: any;
  mode = "update";
  isReadOnly: boolean;
  drawerTitle: any;
  constructor(
    private showsService: ShowsService,
    private router: Router,
    private activatedRouter: ActivatedRoute,
    private logger: LoggerService,
    private helperService: HelperService,
    private drawerService: NzDrawerService,
    private modalService: NzModalService,
    private interactionService: InteractionService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.activatedRouter.params.subscribe(params => {
      this.showId = params["showId"];
      this.prepareData();
    });
    this.isReadOnly = this.helperService.isReadOnly("Show");
  }

  linkClickHandler(type: any) {
    let routerLink = "/system/listing/shows";
    this.router.navigate([routerLink]);
  }

  async prepareData() {
    await this.getShowInfo();
    await this.getShowStatus();

    if (this.showIn && this.showStatus) {
      this.interactionService.sendInteraction("breadcrumb", "shot-listing", {
        showId: this.showId,
        showName: this.showIn.showName
      });
      this.prepareCardData();
    } else {
      this.isEmptyData = true;
    }
  }

  async getShowInfo() {
    await this.showsService
      .getShowInfo(this.showId)
      .toPromise()
      .then((resp: any) => {
        this.showIn = resp.entity;
      })
      .catch((error: any) => {
        this.showIn = null;
      });
  }

  async getShowStatus() {
    await this.showsService
      .getShowStatus(this.showId)
      .toPromise()
      .then((resp: any) => {
        this.showStatus = resp.entity;
      })
      .catch((error: any) => {
        this.showStatus = null;
      });
  }

  prepareCardData() {
    this.cardData = {
      headerTitle: this.showIn.showName,
      footerTitle: "Description",
      footerSubTitle: this.showIn.description,
      thumbnail: this.showIn.thumbnail,
      isFavorite: this.showIn.favorite ? true : false,
      descriptions: [
        /*{
          name: "Status",
          class: "label",
          value: this.showIn.status
        },*/
        {
          name: "Show ID",
          class: "label",
          value: this.showIn.id
        },
        {
          name: "Client",
          class: "label label-green",
          value: this.showIn.clientName
        },
        {
          name: "Shot Attributes",
          class: "label label-green",
          value: this.showIn.shotAttributeNames
        }
      ]
    };
    this.isDataReady = true;
    console.log(this.cardData);
  }

  backupHandler() {
    this.openBackupForm();
  }

  async editHandler() {
    await this.getShow(this.showId);
    if (this.showOut) {
      this.openShowForm();
    }
  }

  async likeHandler() {
    if (this.showIn.favorite) {
      await this.dislikeShow(this.showId);
    } else {
      await this.likeShow(this.showId);
    }
    //await this.dislikeShow(this.showId);
  }

  async getShow(id: any) {
    this.showOut = null;
    await this.showsService
      .getShow(id)
      .toPromise()
      .then(resp => {
        if (resp && resp.valid && resp.entity) {
          this.showOut = resp.entity;
        }
      })
      .catch(error => {
        console.log(JSON.stringify(error));
      });
  }

  async dislikeShow(id: any) {
    let successMessage = AppConstants.SHOW_DISLIKE_SUCCESS;
    let errorMessage = AppConstants.SHOW_DISLIKE_ERROR;
    await this.showsService
      .dislikeShow(id)
      .toPromise()
      .then(resp => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: successMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
        this.prepareData();
      })
      .catch(error => {
        if (error && error.error && error.error.body) {
          if (error.error.body[0] && error.error.body[0].message) {
            errorMessage =
              errorMessage + "<br/>Reason : " + error.error.body[0].message;
          }
        }
        this.showNotification({
          type: "error",
          title: "Error",
          content: errorMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  }
  async likeShow(id: any) {
    let likeIn = {
      entityTypeName: "Show",
      entityId: id
    };
    let successMessage = AppConstants.SHOW_LIKE_SUCCESS;
    let errorMessage = AppConstants.SHOW_LIKE_ERROR;
    await this.showsService
      .likeShow(likeIn)
      .toPromise()
      .then(resp => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: successMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
        this.prepareData();
      })
      .catch(error => {
        if (error && error.error && error.error.body) {
          if (error.error.body[0] && error.error.body[0].message) {
            errorMessage =
              errorMessage + "<br/>Reason : " + error.error.body[0].message;
          }
        }
        this.showNotification({
          type: "error",
          title: "Error",
          content: errorMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  }

  showNotification(info: any) {
    this.notificationService.showNotification(info);
  }

  openBackupForm(): void {
    this.drawerTitle = "Backup Show";
    this.childDrawerRef = this.drawerService.create<
      BackupFormComponent,
      { showOut: any },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: BackupFormComponent,
      nzContentParams: {
        showOut: this.showOut
      },
      nzClosable: false,
      nzWidth: "30%",
      nzWrapClassName: "modal-wrapper",
      nzOnCancel: () =>
        new Promise((resolve, reject) => {
          this.modalService.confirm({
            nzTitle: AppConstants.EXIT_WARNING_MESSAGE,
            nzOkText: "Yes",
            nzOkType: "default",
            nzOnOk: () => resolve(true),
            nzCancelText: "No",
            //nzCancelType: "primary",
            nzOnCancel: () => resolve(false)
          });
          return;
        })
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("childDrawerRef Drawer(Component) open");
    });

    this.childDrawerRef.afterClose.subscribe(isSuccess => {
      console.log("childDrawerRef afterClose DATA " + isSuccess);
      if (isSuccess) {
        this.prepareData();
      }
    });
  }

  openShowForm(): void {
    this.drawerTitle = "Edit Show";
    this.childDrawerRef = this.drawerService.create<
      ShowFormComponent,
      { showOut: any; mode: string },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: ShowFormComponent,
      nzContentParams: {
        showOut: this.showOut,
        mode: this.mode
      },
      nzClosable: false,
      nzWidth: "30%",
      nzWrapClassName: "modal-wrapper",
      nzOnCancel: () =>
        new Promise((resolve, reject) => {
          this.modalService.confirm({
            nzTitle: AppConstants.EXIT_WARNING_MESSAGE,
            nzOkText: "Yes",
            nzOkType: "default",
            nzOnOk: () => resolve(true),
            nzCancelText: "No",
            //nzCancelType: "primary",
            nzOnCancel: () => resolve(false)
          });
          return;
        })
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("childDrawerRef Drawer(Component) open");
    });

    this.childDrawerRef.afterClose.subscribe(isSuccess => {
      console.log("childDrawerRef afterClose DATA " + isSuccess);
      if (isSuccess) {
        this.prepareData();
      }
    });
  }

  closeForm(): void {
    this.childDrawerRef.close();
  }
}
