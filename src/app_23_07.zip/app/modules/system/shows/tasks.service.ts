import { Injectable } from '@angular/core';
import { HttpService } from "../../core/services/http.service";
import { LoggerService } from "../../core/services/logger.service";
import { environment } from "src/environments/environment";
import { AppConstants } from "src/app/constants/AppConstants";

@Injectable({
  providedIn: 'root'
})
export class TasksService {

  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */

  constructor(private http: HttpService, private logger: LoggerService) { }

  getTaskProgressByShot(ids: any) {
    let endPoint = this.apiUrl + AppConstants.TASK_PROGRESS_SHOT + ids;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-progress-shot";
    }
    this.logger.log("TasksService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTaskProgressByAsset(ids: any) {
    let endPoint = this.apiUrl + AppConstants.TASK_PROGRESS_ASSET + ids;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-progress-asset";
    }
    this.logger.log("TasksService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTaskProgressByTask(ids: any) {
    let endPoint = this.apiUrl + AppConstants.TASK_PROGRESS_TASK + ids;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-progress-task";
    }
    this.logger.log("TasksService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTaskNotesByTask(id: any) {
    let endPoint = this.apiUrl + AppConstants.NOTES + '/6/' + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-notes";
    }
    this.logger.log("TasksService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  createNote(noteIn: any) {
    let endPoint = this.apiUrl + AppConstants.NOTES;
    this.logger.log("TasksService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, noteIn);
  }

}
