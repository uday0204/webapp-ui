import { Injectable } from "@angular/core";
import { HttpService } from "../../core/services/http.service";
import { LoggerService } from "../../core/services/logger.service";
import { environment } from "src/environments/environment";
import { AppConstants } from "src/app/constants/AppConstants";

@Injectable({
  providedIn: 'root'
})
export class AssetsService {

  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */


  constructor(private http: HttpService, private logger: LoggerService) { }

  /** Asset APIs START */

  createAsset(assetIn: any) {
    const endPoint = this.apiUrl + AppConstants.ASSET;
    this.logger.log("AssetsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, assetIn);
  }

  getAsset(id: any) {
    let endPoint = this.apiUrl + AppConstants.ASSET + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "asset";
    }
    this.logger.log("AssetsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  updateAsset(assetIn: any) {
    const endPoint = this.apiUrl + AppConstants.ASSET + "/" + assetIn.id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, assetIn);
  }

  deleteAsset(id: any) {
    const endPoint = this.apiUrl + AppConstants.ASSET + "/" + id + '/delete';
    this.logger.log("AssetsService Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, null);
  }

  getAssetListByShowId(showId: any) {
    let endPoint = this.apiUrl + AppConstants.ASSET_LIST + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "asset-list";
    }
    this.logger.log("AssetsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getAssetTableList(page: any, showId: any, filterParams?: any) {
    //let params = `search=&showId=${showId}`;
    let params = `showId=${showId}`;
    if (page) {
      if (page.search) {
        params += `&search=${page.search}`;
      } else {
        params += `&search=`;
      }
      params += `&pageNo=${page.pageNumber}&pageSize=${page.size}&sortBy=${page.sortBy}&orderBy=${page.orderBy}`;
    }
    if (filterParams && filterParams !== "") {
      params += `&${filterParams}`;
    }
    let endPoint = this.apiUrl + AppConstants.ASSET_LIST + "?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "asset-list-table";
    }
    this.logger.log("AssetsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  inlineEdit(id: any, assetIn: any) {
    const endPoint = this.apiUrl + AppConstants.ASSET_INLINE_EDIT + "/" + id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.patch<any>(endPoint, assetIn);
  }

  getAssetTypes() {
    let endPoint = this.apiUrl + AppConstants.ASSET_TYPES;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "asset-types";
    }
    this.logger.log("AssetsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getAssetInfo(id: any) {
    let endPoint = this.apiUrl + AppConstants.ASSET_INFO + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "asset-info";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getAssetStatus(id: any) {
    let endPoint = this.apiUrl + AppConstants.ASSET_STATUS + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "asset-status";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getSubAssetList(showId: any) {
    let endPoint = this.apiUrl + AppConstants.ASSET_LIST + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getParentAssetList(showId: any) {
    let endPoint = this.apiUrl + AppConstants.ASSET_LIST + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** Asset APIs END */
}
