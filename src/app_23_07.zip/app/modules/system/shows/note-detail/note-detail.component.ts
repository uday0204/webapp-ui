import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { InteractionService } from 'src/app/modules/core/services/interaction.service';

@Component({
  selector: 'app-note-detail',
  templateUrl: './note-detail.component.html',
  styleUrls: ['./note-detail.component.scss']
})
export class NoteDetailComponent implements OnInit {

  showId: any;
  noteId: any;
  noteIn: any;
  constructor(
    private activatedRouter: ActivatedRoute,
    private interactionService: InteractionService
  ) { }

  ngOnInit() {
    this.activatedRouter.params.subscribe(params => {
      this.showId = params["showId"];
      this.noteId = params["noteId"];
      this.prepareData();
    });
  }

  async prepareData() {
    await this.getNoteInfo();
    if (this.noteIn) {
      let showName = this.noteIn.showName
        ? this.noteIn.showName
        : this.noteIn.showId;
      this.interactionService.sendInteraction(
        "breadcrumb",
        "note-listing",
        {
          showId: this.showId,
          showName: showName,
          noteName: this.noteIn.noteName,
          noteId: this.noteId
        }
      );
    }

  }

  async getNoteInfo() {

  }

}
