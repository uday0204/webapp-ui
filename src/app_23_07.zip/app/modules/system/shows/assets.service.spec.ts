import { TestBed } from '@angular/core/testing';

import { AssetsService } from './assets.service';

describe('AssetsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AssetsService = TestBed.get(AssetsService);
    expect(service).toBeTruthy();
  });
});
