import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { HelperService } from "src/app/modules/core/services/helper.service";

@Component({
  selector: "app-card-view",
  templateUrl: "./card-view.component.html",
  styleUrls: ["./card-view.component.scss"]
})
export class CardViewComponent implements OnInit {
  @Input() data: any;
  @Input() isReadOnly: boolean;
  @Input() type: any;

  @Output("edit") onEdit = new EventEmitter<any>();
  @Output("like") onLike = new EventEmitter<any>();
  @Output("backup") onBackup = new EventEmitter<any>();


  constructor(private helperService: HelperService) { }

  ngOnInit() { }

  editHandler() {
    this.onEdit.emit();
  }

  getIconType() {
    return "star";
  }

  getIconTheme() {
    let isFavorite = false;
    if (this.data.isFavorite) {
      isFavorite = true;
    }
    return isFavorite ? "fill" : "outline";
  }

  likeHandler() {
    this.onLike.emit();
  }

  backupHandler() {
    this.onBackup.emit();
  }

  showLikeIcon() {
    let show = false;
    if (this.data.hasOwnProperty("isFavorite")) {
      show = true;
    }
    return show;
  }

  showBackupMenu() {
    if (this.type && this.type === 'show') {
      return true;
    }
    return false;
  }
}
