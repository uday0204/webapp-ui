import { Injectable } from "@angular/core";
import { HttpService } from "../../core/services/http.service";
import { LoggerService } from "../../core/services/logger.service";
import { environment } from "src/environments/environment";
import { AppConstants } from "src/app/constants/AppConstants";

@Injectable({
  providedIn: "root"
})
export class ShowsService {
  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */

  constructor(private http: HttpService, private logger: LoggerService) {}

  /** Show APIs START */

  createShow(showIn: any) {
    const endPoint = this.apiUrl + AppConstants.SHOW;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, showIn);
  }

  likeShow(likeIn: any) {
    const endPoint = this.apiUrl + AppConstants.FAVORITE;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, likeIn);
  }

  dislikeShow(id: any) {
    const endPoint = this.apiUrl + AppConstants.REMOVE_FAVORITE + "/Show/" + id;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, null);
  }

  getShow(id: any) {
    let endPoint = this.apiUrl + AppConstants.SHOW + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  updateShow(showIn: any) {
    const endPoint = this.apiUrl + AppConstants.SHOW + "/" + showIn.id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, showIn);
  }

  deleteShow(id: any) {
    const endPoint = this.apiUrl + AppConstants.SHOW + "/" + id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.delete<any>(endPoint);
  }

  getShowList() {
    let endPoint = this.apiUrl + AppConstants.SHOW_LIST;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getShows() {
    let endPoint = this.apiUrl + AppConstants.SHOWS;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shows";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getShowsByArist() {
    let endPoint = this.apiUrl + AppConstants.ARIST_SHOWS;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shows-by-artist";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getShowInfo(id: any) {
    let endPoint = this.apiUrl + AppConstants.SHOW_INFO + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show-info";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getShowStatus(id: any) {
    let endPoint = this.apiUrl + AppConstants.SHOW_STATUS + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show-status";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTaskTypesByShowId(showId) {
    let endPoint =
      this.apiUrl + AppConstants.SHOW_LIST_TASK_TYPES + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show-task-types";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getSupervisorsByShowId(showId) {
    let endPoint =
      this.apiUrl + AppConstants.SHOW_LIST_SUPERVISORS + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show-supervisors";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getArtistsByShowId(showId) {
    let endPoint = this.apiUrl + AppConstants.SHOW_ARTIST_LIST + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show-members";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** Show APIs END */

  /** Shot APIs START */

  createShot(shotIn: any) {
    const endPoint = this.apiUrl + AppConstants.SHOT;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, shotIn);
  }

  manualInsertion(info: any) {
    const endPoint = this.apiUrl + AppConstants.MANUAL_INSERTION;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, info);
  }

  getShot(id: any) {
    let endPoint = this.apiUrl + AppConstants.SHOT + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  updateShot(shotIn: any) {
    const endPoint = this.apiUrl + AppConstants.SHOT + "/" + shotIn.id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, shotIn);
  }

  deleteShot(id: any) {
    const endPoint = this.apiUrl + AppConstants.SHOT + "/" + id + "/delete";
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, null);
  }

  inlineEditShot(id: any, shotIn: any) {
    const endPoint = this.apiUrl + AppConstants.SHOT_INLINE_EDIT + "/" + id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.patch<any>(endPoint, shotIn);
  }

  getShotList(page: any, showId: any, filterParams?: any) {
    let params = `showId=${showId}`;
    if (page) {
      if (page.search) {
        params += `&search=${page.search}`;
      } else {
        params += `&search=`;
      }
      params += `&pageNo=${page.pageNumber}&pageSize=${page.size}&sortBy=${page.sortBy}&orderBy=${page.orderBy}`;
    }
    if (filterParams && filterParams !== "") {
      params += `&${filterParams}`;
    }
    let endPoint = this.apiUrl + AppConstants.SHOT_LIST + "?" + params;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-list-table";
    }

    return this.http.get<any>(endPoint);
  }

  getShotInfo(id: any) {
    let endPoint = this.apiUrl + AppConstants.SHOT_INFO + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-info";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getShotStatus(id: any) {
    let endPoint = this.apiUrl + AppConstants.SHOT_STATUS + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-status";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getLinkedShotList(showId: any) {
    let endPoint = this.apiUrl + AppConstants.SHOT_LIST + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getSubShotList(showId: any) {
    let endPoint = this.apiUrl + AppConstants.SHOT_LIST + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getParentShotList(showId: any) {
    let endPoint = this.apiUrl + AppConstants.SHOT_LIST + "/" + showId;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getShotColumnList() {
    let endPoint = this.apiUrl + AppConstants.SHOT_COLUMN_LIST;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-column-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getAllStatus() {
    let endPoint = this.apiUrl + AppConstants.SHOT_ALL_STATUS;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-all-status";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** Shot APIs END */

  /** Task APIs START */

  createTask(taskIn: any) {
    const endPoint = this.apiUrl + AppConstants.TASK;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, taskIn);
  }

  getTask(id: any) {
    let endPoint = this.apiUrl + AppConstants.TASK + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  updateTask(taskIn: any) {
    const endPoint = this.apiUrl + AppConstants.TASK + "/" + taskIn.id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, taskIn);
  }

  deleteTask(id: any) {
    const endPoint = this.apiUrl + AppConstants.TASK + "/" + id + "/delete";
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, null);
  }

  inlineEditTask(id: any, taskIn: any) {
    const endPoint = this.apiUrl + AppConstants.TASK_INLINE_EDIT + "/" + id;
    this.logger.log("Calling endpoint " + endPoint);
    return this.http.patch<any>(endPoint, taskIn);
  }

  getTasksByShowId(page: any, showId: any) {
    let params = `search=&showId=${showId}&pageNo=${page.pageNumber}&pageSize=${page.size}`;
    let endPoint = this.apiUrl + AppConstants.TASK_LIST_FILTER + "?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-list-by-show";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTasksByView(page: any, params: any, viewType: any) {
    let endPoint =
      this.apiUrl +
      AppConstants.TASK_LIST_FILTER_NEW +
      "/" +
      viewType +
      "?" +
      params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-list-by-show-shot";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTasksByShowAndShotIds(page: any, params: any) {
    /*let params = `search=&showId=${showId}&pageNo=${page.pageNumber}&pageSize=${page.size}`;
    if (shotId) {
      params += `&shotId=${shotId}`;
    }*/
    let endPoint = this.apiUrl + AppConstants.TASK_LIST_FILTER + "?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-list-by-show-shot";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTasksByAssetId(page: any, params: any) {
    let endPoint =
      this.apiUrl + AppConstants.TASK_LIST_ASSET_FILTER + "?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-list-by-asset";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTasksByArtistId(id: any) {
    let endPoint = this.apiUrl + AppConstants.TASK_BY_ARTIST + "/" + id;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-list-by-asset";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTaskColumnList() {
    let endPoint = this.apiUrl + AppConstants.TASK_COLUMN_LIST;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-column-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTaskPriorities() {
    let endPoint = this.apiUrl + AppConstants.TASK_PRIORITIES;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "list-task-priority";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getMyTaskShotView(showId: any, params: any) {
    //let endPoint = this.apiUrl + AppConstants.MY_TASK + '/' + showId + '/SHOT_VIEW' + "?" + params;
    let endPoint =
      this.apiUrl + AppConstants.MY_TASK + "/SHOT_VIEW" + "?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "my-task-shot-view";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getMyTaskAssetView(showId: any, params: any) {
    //let endPoint = this.apiUrl + AppConstants.MY_TASK + '/' + showId + '/ASSET_VIEW' + "?" + params;
    let endPoint =
      this.apiUrl + AppConstants.MY_TASK + "/ASSET_VIEW" + "?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "my-task-asset-view";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getArtistTaskList() {
    let endPoint = this.apiUrl + AppConstants.TASK + "/list/artist";
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-list-artist";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getVersionsByTaskId(page: any, taskId: any) {
    let params = `search=${page.search}&pageNo=${page.pageNumber}&pageSize=${page.size}`;
    let endPoint =
      this.apiUrl + AppConstants.TASK_VERSIONS + "/" + taskId + "?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-versions";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** Task APIs END */

  /** User APIs START */

  getClientList() {
    let endPoint = this.apiUrl + AppConstants.CLIENT_LIST;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "client-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getUserList() {
    let endPoint = this.apiUrl + AppConstants.USER_LIST;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "user-list";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getSupervisorList() {
    let endPoint = this.apiUrl + AppConstants.SUPERVISOR_LIST;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "supervisor-list2";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** User APIs END */

  /** Template APIs START */

  getShowTemplates() {
    let endPoint = this.apiUrl + AppConstants.SHOW_TEMPLATES;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "show-templates";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getShotTemplates() {
    let endPoint = this.apiUrl + AppConstants.SHOT_TEMPLATES;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-templates";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getPackingTemplates() {
    let endPoint = this.apiUrl + AppConstants.PACKING_TEMPLATES;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "packing-templates";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  getTaskTemplates() {
    let endPoint = this.apiUrl + AppConstants.TASK_TEMPLATES;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "task-templates";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  /** Template APIs END */

  /** Others APIs START */

  getShotAttributes() {
    let endPoint = this.apiUrl + AppConstants.SHOT_ATTRIBUTES;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "shot-attributes";
    }
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  uploadFile(formData: any) {
    let endPoint = this.apiUrl + AppConstants.UPLOAD_FILE;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, formData);
  }

  uploadFileEndPoint() {
    return this.apiUrl + AppConstants.UPLOAD_FILE;
  }
  uploadCSVFileEndPoint() {
    return this.apiUrl + AppConstants.UPLOAD_CSV_FILE;
    // + "csv/upload/1";
  }
  getCSVHeaders() {
    let endPoint = this.apiUrl + AppConstants.CSV_HEADERS;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "csv-headers";
    }
    return this.http.get<any>(endPoint);
  }

  validateCSV(csvIn: any, showId: any, processId: any) {
    let endPoint = this.apiUrl + `csv/upload/${showId}/${processId}/validate`;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, csvIn);
  }

  validateData(dataIn: any, showId: any, processId: any) {
    let endPoint =
      this.apiUrl + `csv/upload/${showId}/${processId}/validate-data`;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, dataIn);
  }

  submitData(showId: any, processId: any) {
    let endPoint = this.apiUrl + `csv/upload/${showId}/${processId}/submit`;
    this.logger.log("ShowsService Calling endpoint " + endPoint);
    return this.http.post<any>(endPoint, null);
  }

  /** Others APIs END */
}
