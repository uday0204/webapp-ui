import {
  Component,
  OnInit,
  Input,
  TemplateRef,
  ViewChild,
  OnDestroy
} from "@angular/core";
import { NotificationService } from "src/app/modules/core/services/notification.service";
import { NzDrawerService, UploadChangeParam, NzModalService } from "ng-zorro-antd";
import { ShowsService } from "../shows.service";
import { Router } from "@angular/router";
import { Page } from "src/app/modules/shared/model/page";
import { TableColumnsSettingsComponent } from "../../modals/table-columns-settings/table-columns-settings.component";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { AppConstants } from "src/app/constants/AppConstants";
import { SequencesService } from "../sequences.service";
import { ShotFormComponent } from "../../modals/shot-form/shot-form.component";
import { TasksService } from "../tasks.service";
import { ShotFilterSettingsComponent } from "../../modals/shot-filter-settings/shot-filter-settings.component";
import { InteractionService } from "src/app/modules/core/services/interaction.service";
import { Subscription } from "rxjs";
import { BackupFormComponent } from '../../modals/backup-form/backup-form.component';

@Component({
  selector: "app-shotlist-tab",
  templateUrl: "./shotlist-tab.component.html",
  styleUrls: ["./shotlist-tab.component.scss"]
})
export class ShotlistTabComponent implements OnInit, OnDestroy {
  @Input() showIn: any;
  @Input() isReadOnly: boolean;
  @ViewChild("drawerHeader", { static: false }) drawerHeader: TemplateRef<{}>;
  @ViewChild("myTable", { static: false }) table: any;

  childDrawerRef: any;
  isEmptyData: boolean;
  isDataReady: boolean;
  showDummy: boolean;
  isLoading: boolean = true;
  rows: any;
  showId: any;
  page = new Page();
  pageSizeOptions: any;
  selectedPageSize: any;
  editing = {};
  tableColumns: any;
  selectedTableColumns: any;
  isEditSuccess: boolean;
  shotToDelete: any;
  isAlertVisible: boolean;

  /** Dropdown inline edit vars - START */
  isVisible: boolean;
  modalTitle: any;
  myrow: any;
  mycol: any;

  isSequenceSelect: boolean;
  sequences: any;
  selectedSequenceId: any;

  isStatusSelect: boolean;
  statuses: any;
  selectedStatus: any;

  isSupervisorSelect: boolean;
  supervisors: any;
  selectedSupervisorId: any;

  isThumbnailSelect: boolean;
  selectedThumbnailUrl: any;

  /** Dropdown inline edit vars - END*/
  shotOut: any;
  currPageInfo: any;
  sortBy: any = "shotCode";
  orderBy: any = "ASC";
  drawerTitle: any;

  selected = [];
  taskProgress: any;
  isProgressVisible: boolean;
  progressConfig: any;

  isSearching: boolean;
  searchPattern = "";

  shotFilters: any;
  subscription: Subscription;
  tableHeight: any = "calc(100vh - 200px)";

  constructor(
    private showsService: ShowsService,
    private sequencesService: SequencesService,
    private drawerService: NzDrawerService,
    private modalService: NzModalService,
    private notificationService: NotificationService,
    private router: Router,
    private interactionService: InteractionService,
    private helperService: HelperService,
    private tasksService: TasksService
  ) {
    this.page.pageNumber = 0;
    this.page.size = 10;
    this.pageSizeOptions = AppConstants.TABLE_PAGE_SIZE_OPTIONS;
    this.selectedPageSize = this.page.size; //.toString();
  }

  ngOnInit() {
    this.isReadOnly = this.helperService.isReadOnly("Shot");
    this.showId = this.showIn.id;
    this.getStatuses();
    this.getTableColumns();
    this.progressConfig = {
      showInfo: true,
      type: "circle",
      strokeLinecap: "round",
      strokeWidth: 8,
      strokeColor: "#3be582"
    };
    this.shotFilters = {
      seasonIds: [],
      episodeIds: [],
      sequenceIds: [],
      spotIds: [],
      status: []
    };
  }

  ngOnDestroy() {
    //this.subscription.unsubscribe();
  }

  async getTableColumns() {
    await this.getShotColumnList();
    if (this.tableColumns) {
      this.frameSelectedColumns();
      this.isDataReady = true;
    }
  }

  async getShotColumnList() {
    await this.showsService
      .getShotColumnList()
      .toPromise()
      .then((resp: any) => {
        if (resp && resp.entity && resp.entity.fields) {
          this.tableColumns = resp.entity.fields;
          if (!this.isReadOnly) {
            this.addEditableFlag(this.tableColumns);
          }
        }
      })
      .catch((error: any) => {
        this.tableColumns = null;
      });
  }

  addEditableFlag(tableColumns) {
    let nonEditableCols = [
      "shotCode",
      "episodeName",
      "seasonName",
      "spotName",
      "completionPercentage",
      "sequenceName"
    ];
    tableColumns.map((item: any) => {
      item.isEditable = nonEditableCols.includes(item.name) ? false : true;
      return item;
    });
  }

  frameSelectedColumns() {
    this.selectedTableColumns = this.tableColumns.filter((item, index) => {
      if (item.name === "spotName") {
        item.defaultDisplay = true;
      }
      item["index"] = index;
      return item.defaultDisplay;
    });
  }

  searchHandler() {
    this.isSearching = true;
  }

  searchDetails() {
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  searchBlur() {
    if (this.searchPattern == "") {
      this.isSearching = false;
    }
    /*this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);*/
  }

  setPageSize() {
    this.currPageInfo.pageSize = this.selectedPageSize;
    this.currPageInfo.offset = 0;
    this.setPage(this.currPageInfo);
  }

  getId(row) {
    return row.id;
  }

  setPage(pageInfo) {
    this.currPageInfo = pageInfo;
    this.isLoading = true;
    this.page.pageNumber = pageInfo.offset;
    this.page.size = pageInfo.pageSize;
    this.page.search = this.searchPattern;
    this.page.sortBy = this.sortBy;
    this.page.orderBy = this.orderBy;
    this.showDummy = false;
    let filterParams = this.getFilterParams();
    this.showsService
      .getShotList(this.page, this.showId, filterParams)
      .subscribe(
        resp => {
          if (resp && resp.valid) {
            this.page.totalElements = resp.total;
            this.page.totalPages = Math.ceil(resp.total / this.page.size);
            this.rows = resp.coll;
            setTimeout(() => {
              this.isLoading = false;
              this.table.recalculate();
              try {
                if (!this.isValidArr(this.rows)) {
                  this.frameSelectedColumns();
                  this.table.headerComponent.offsetX = 0;
                }
                let parentHeight = this.table.bodyComponent.scroller.parentElement.getBoundingClientRect()
                  .height;
                let childHeight = this.table.bodyComponent.scroller.element.getBoundingClientRect()
                  .height;
                if (childHeight > parentHeight) {
                  this.showDummy = false;
                } else {
                  this.showDummy = true;
                }
                if (this.rows.length <= 10) {
                  this.showDummy = true;
                }
              } catch (e) { }
            }, 500);
          } else {
            this.onDataError(resp);
          }
          this.setTableHeight();
          //setTimeout(() => this.isHidden = false, 5000);
        },
        error => {
          this.isLoading = false;
          this.onDataError(error);
          this.setTableHeight();
        }
      );
  }

  onDataError(error: any) {
    console.log("<< onDataError >> " + error);
    this.isEmptyData = true;
  }

  imageEditHandler(row: any) {
    console.log(row);
  }

  createShot() {
    this.drawerTitle = "Add Shot";
    let shotOut = {
      showId: this.showId
    };
    this.openShotForm("create", shotOut);
  }

  async editHandler(row: any) {
    await this.getShot(row.id);
    if (this.shotOut) {
      this.drawerTitle = "Edit Shot";
      this.openShotForm("update", this.shotOut);
    }
  }

  async getShot(id: any) {
    await this.showsService
      .getShot(id)
      .toPromise()
      .then(resp => {
        this.shotOut = resp.entity;
      })
      .catch(error => {
        console.log(error);
        this.shotOut = null;
      });
  }

  setTableHeight() {
    if (!this.isValidArr(this.rows)) {
      this.tableHeight = 150 + "px";
    } else {
      if (this.rows.length <= 10) {
        this.tableHeight = this.rows.length * 50 + 120 + "px";
        //this.tableHeight = (this.rows.length * 50) + 'px';
      } else {
        this.tableHeight = "calc(100vh - 200px)";
      }
    }
    //this.tableHeight = 'calc(100vh - 200px)';
  }

  getTableHeight() {
    return this.tableHeight;
    /*if (!this.rows) {
      return 100 + 'px';
    }
    if (this.rows.length <= 0) {
      return 100 + 'px';
    }
    return 'calc(100vh - 200px)';
    if (this.rows && this.rows.length > 0) {
      if (this.rows.length <= 10) {
        return (this.rows.length * 50) + 100 + 'px';
      } else {
        return 'calc(100vh - 200px)';
      }
    } else {
      return 100 + 'px';
    }    
    let height = (this.selectedPageSize * 50) + 100 + 'px';
    console.log('innerHeight >> ' + window.innerHeight);
    console.log('getTableHeight >> ' + height);
    return height;*/
  }

  openShotForm(mode: any, shotOut: any): void {
    this.childDrawerRef = this.drawerService.create<
      ShotFormComponent,
      {
        shotOut: any;
        mode: string;
        disableShowSelect?: boolean;
        showName?: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: ShotFormComponent,
      nzContentParams: {
        shotOut: shotOut,
        mode: mode,
        disableShowSelect: true,
        showName: this.showIn.showName
      },
      nzClosable: false,
      nzWidth: "500px",
      nzWrapClassName: "modal-wrapper",
      nzOnCancel: () =>
        new Promise((resolve, reject) => {
          this.modalService.confirm({
            nzTitle: AppConstants.EXIT_WARNING_MESSAGE,
            nzOkText: "Yes",
            nzOkType: "default",
            nzOnOk: () => resolve(true),
            nzCancelText: "No",
            //nzCancelType: "primary",
            nzOnCancel: () => resolve(false)
          });
          return;
        })
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("Shot Form Open");
    });

    this.childDrawerRef.afterClose.subscribe(isSuccess => {
      console.log("childDrawerRef afterClose DATA " + isSuccess);
      if (isSuccess) {
        this.setPage(this.currPageInfo);
      }
    });
  }

  closeForm(): void {
    this.childDrawerRef.close();
  }

  packageHandler(row: any) {
    this.drawerTitle = "Shot Package";
    this.openPackageForm(row);
  }


  openPackageForm(shotOut: any): void {
    this.childDrawerRef = this.drawerService.create<
      BackupFormComponent,
      {
        shotOut: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: BackupFormComponent,
      nzContentParams: {
        shotOut: shotOut,
      },
      nzClosable: false,
      nzWidth: "500px",
      nzWrapClassName: "modal-wrapper",
      nzOnCancel: () =>
        new Promise((resolve, reject) => {
          this.modalService.confirm({
            nzTitle: AppConstants.EXIT_WARNING_MESSAGE,
            nzOkText: "Yes",
            nzOkType: "default",
            nzOnOk: () => resolve(true),
            nzCancelText: "No",
            //nzCancelType: "primary",
            nzOnCancel: () => resolve(false)
          });
          return;
        })
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("Shot Form Open");
    });

    this.childDrawerRef.afterClose.subscribe(isSuccess => {
      console.log("childDrawerRef afterClose DATA " + isSuccess);
      if (isSuccess) {
        this.setPage(this.currPageInfo);
      }
    });
  }

  deleteHandler(row: any) {
    this.isAlertVisible = true;
    this.shotToDelete = row;
  }

  deleteShotConfirm = async () => {
    console.log("Delete Shot " + this.shotToDelete.id);
    let successMessage = "Shot has been successfully deleted.";
    let errorMessage = "Shot deletion failed.";
    this.isAlertVisible = false;
    await this.showsService
      .deleteShot(this.shotToDelete.id)
      .toPromise()
      .then(resp => {
        this.showNotification({
          type: "success",
          title: "Success",
          content: successMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
        this.setPage(this.currPageInfo);
      })
      .catch(error => {
        let errorDetails = this.helperService.getErrorDetails(error);
        if (errorDetails !== "") {
          errorMessage = `<b>${errorMessage}</b>` + errorDetails;
        }
        this.showNotification({
          type: "error",
          title: "Error",
          content: errorMessage,
          duration: AppConstants.NOTIFICATION_DURATION
        });
      });
  };

  deleteShotCancel = () => {
    this.isAlertVisible = false;
    console.log("deleteShotCancel ");
  };

  onShotCodeClick(row) {
    let routerLink = this.router.url + "/shots/" + row.id;
    this.router.navigate([routerLink]);
  }

  onSort(event) {
    this.sortBy = event.sorts[0].prop;
    this.orderBy = event.sorts[0].dir.toUpperCase();
    this.currPageInfo.offset = 0;
    if (this.sortBy === "tailOutCode") {
      this.sortBy = "tailOut";
    }
    this.setPage(this.currPageInfo);
  }

  clickHandler() {
    this.drawerTitle = "Table Columns";
    this.openColumnsSelectionForm();
  }

  filterHandler() {
    this.drawerTitle = "Filter Settings";
    this.openFilterSettingsForm();
  }

  openColumnsSelectionForm(): void {
    this.childDrawerRef = this.drawerService.create<
      TableColumnsSettingsComponent,
      {
        tableColumns: any;
        selectedTableColumns: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: TableColumnsSettingsComponent,
      nzContentParams: {
        tableColumns: this.tableColumns,
        selectedTableColumns: this.selectedTableColumns
      },
      nzClosable: false,
      nzWidth: "40%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("childDrawerRef Drawer(Component) open");
    });

    this.childDrawerRef.afterClose.subscribe(data => {
      console.log("inside this.childDrawerRef.afterClose.subscribe" + data);
      if (data) {
        if (
          JSON.stringify(this.selectedTableColumns) !== JSON.stringify(data)
        ) {
          this.selectedTableColumns = data;
          this.setPage(this.currPageInfo);
        } else {
          console.log("No change in the settings : Do nothing !!! ");
        }
      }
    });
  }

  openFilterSettingsForm(): void {
    this.childDrawerRef = this.drawerService.create<
      ShotFilterSettingsComponent,
      {
        type: any;
        filters: any;
        showId: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: ShotFilterSettingsComponent,
      nzContentParams: {
        type: "shot",
        filters: this.shotFilters,
        showId: this.showId
      },
      nzClosable: false,
      nzWidth: "40%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("childDrawerRef Drawer(Component) open");
    });

    this.childDrawerRef.afterClose.subscribe(data => {
      if (data) {
        if (JSON.stringify(this.shotFilters) !== JSON.stringify(data)) {
          this.shotFilters = data;
          this.currPageInfo.offset = 0;
          this.setPage(this.currPageInfo);
        } else {
          console.log("No change in the settings : Do nothing !!! ");
        }
      }
    });
  }

  getFilterParams() {
    let filterParams = "";
    /*if (this.shotFilters.seasonIds && this.shotFilters.seasonIds.length > 0) {
      if (filterParams != "") {
        filterParams += '&';
      }
      filterParams += `seasonId=${this.shotFilters.seasonIds[0]}`;
    }
    if (this.shotFilters.seasonIds && this.shotFilters.seasonIds.length > 0) {
      if (filterParams != "") {
        filterParams += '&';
      }
      filterParams += `seasonId=${this.shotFilters.seasonIds[0]}`;
    }*/
    for (let i in this.shotFilters) {
      let item = this.shotFilters[i];
      if (item && item.length > 0) {
        if (filterParams != "") {
          filterParams += "&";
        }
        filterParams += `${i}=${item.toString()}`;
      }
    }
    return filterParams;
  }

  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  progressHandler() {
    let selectedIds = this.selected.map(item => {
      return item.id;
    });

    this.tasksService
      .getTaskProgressByShot(selectedIds)
      .toPromise()
      .then(resp => {
        this.isProgressVisible = true;
        if (resp && resp.entity) {
          this.taskProgress = Math.round(resp.entity);
        } else {
          this.taskProgress = 0;
        }
      })
      .catch(error => { });
  }

  getColWidth(colName) {
    if (colName === "shotName") {
      return 200;
    } else if (colName === "completionPercentage") {
      return 200;
    } else if (colName === "description") {
      return 200;
    } else if (colName === "sequenceName") {
      return 200;
    } else if (colName === "thumbnail") {
      return 150;
    } else {
      return 150;
    }
  }

  getStatusColorCode(row: any) {
    //console.log(row);
    let defaultCode = "#038e4e";
    let matched = this.helperService.findObjectInArrayByKey(
      this.statuses,
      "value",
      row.status
    );
    //console.log(this.statuses);
    //console.log(matched);
    return matched && matched.code ? matched.code : defaultCode;
    /*
    let code = '#038e4e';
    if (matched && matched.code) {
      code = matched.code;
    }
    return code;*/
  }

  enableEdit(row: any, col: any) {
    console.log(this.editing);
    this.resetEditFlags();
    this.editing[row.id + "-" + col.name] = true;
  }

  resetEditFlags() {
    for (let key in this.editing) {
      if (this.editing.hasOwnProperty(key)) {
        this.editing[key] = false;
      }
    }
  }

  inlineEditHandler(row: any, col: any) {
    this.resetEditFlags();
    this.myrow = row;
    this.mycol = col;

    this.isSequenceSelect = false;
    this.isStatusSelect = false;
    this.isSupervisorSelect = false;
    this.isThumbnailSelect = false;
    this.modalTitle = "";

    if (col.name === "sequenceName") {
      this.modalTitle = "Edit Sequence";
      this.selectedSequenceId = row.sequenceId;
      this.isSequenceSelect = true;
      this.getSequences();
    } else if (col.name === "shootingSupervisorName") {
      this.modalTitle = "Edit Shooting Supervisor";
      this.selectedSupervisorId = row.shootingSupervisorId;
      this.isSupervisorSelect = true;
      this.getSupervisors();
    } else if (col.name === "status") {
      this.modalTitle = "Edit Status";
      this.selectedStatus = row.status;
      this.isStatusSelect = true;
      //this.getStatuses();
    } else if (col.name === "thumbnail") {
      this.modalTitle = "Edit Thumbnail";
      this.selectedThumbnailUrl = row.thumbnail;
      this.isThumbnailSelect = true;
    }
    if (this.modalTitle !== "") {
      this.showModal();
    }
  }

  async inlineEditConfirm(row: any, col: any) {
    let shotId = row.id;
    let shotIn: any;
    this.isVisible = false;
    if (col.name === "sequenceName") {
      console.log(this.selectedSequenceId + " : " + row.sequenceId);
      this.isSequenceSelect = false;
      if (this.selectedSequenceId !== row.sequenceId) {
        shotIn = {
          type: "sequenceId",
          sequenceId: row.sequenceId
        };
        await this.updateConfirm(row, col, shotId, shotIn);
        if (this.isEditSuccess) {
          row[col.name] = this.getSeqNameById(row.sequenceId);
        }
      }
    } else if (col.name === "shootingSupervisorName") {
      console.log(this.selectedSupervisorId + " : " + row.shootingSupervisorId);
      this.isSupervisorSelect = false;
      if (this.selectedSupervisorId !== row.shootingSupervisorId) {
        shotIn = {
          type: "shootingSupervisorId",
          shootingSupervisorId: row.shootingSupervisorId
        };
        await this.updateConfirm(row, col, shotId, shotIn);
        if (this.isEditSuccess) {
          row[col.name] = this.getSupervisorNameById(row.shootingSupervisorId);
        }
      }
    } else if (col.name === "status") {
      console.log(this.selectedStatus + " : " + row.status);
      this.isStatusSelect = false;
      if (this.selectedStatus !== row.status) {
        shotIn = {
          type: "status",
          status: row.status
        };
        await this.updateConfirm(row, col, shotId, shotIn);
        if (!this.isEditSuccess) {
          row.status = this.selectedStatus;
        }
      }
    } else if (col.name === "thumbnail") {
      console.log(this.selectedThumbnailUrl + " : " + row.thumbnail);
      this.isThumbnailSelect = false;
      shotIn = {
        type: "thumbnail",
        thumbnail: row.thumbnail
      };
      await this.updateConfirm(row, col, shotId, shotIn);
    }
  }

  getSupervisorNameById(id: any) {
    let matched = this.helperService.findObjectInArrayByKey(
      this.supervisors,
      "id",
      id
    );
    if (matched) {
      return matched.title;
    } else {
      return "";
    }
  }

  getSeqNameById(id: any) {
    //let matchedSeq = this.sequences[this.sequences.map(function (item) { return item.id; }).indexOf(id)];
    let matchedSeq = this.helperService.findObjectInArrayByKey(
      this.sequences,
      "id",
      id
    );
    if (matchedSeq) {
      return matchedSeq.sequenceName;
    } else {
      return "";
    }
  }

  inlineEditCancel(row: any, col: any) {
    this.isVisible = false;
    if (col.name === "sequenceName") {
      this.isSequenceSelect = false;
      row.sequenceId = this.selectedSequenceId;
    } else if (col.name === "shootingSupervisorName") {
      this.isSupervisorSelect = false;
      row.shootingSupervisorId = this.selectedSupervisorId;
    } else if (col.name === "status") {
      this.isStatusSelect = false;
      row.status = this.selectedStatus;
    } else if (col.name === "thumbnail") {
      this.isThumbnailSelect = false;
      row.thumbnail = this.selectedThumbnailUrl;
    }
  }

  onUploadChange(e: UploadChangeParam) {
    console.log("^^^ *** " + e.type);
    if (e.type === "success") {
      this.myrow.thumbnail = e.file.response.fileDownloadUri;
    }
    if (e.type === "removed") {
      this.myrow.thumbnail = "";
    }
  }

  dateOpenChange(row: any, col: any, isOpen: any) {
    if (!isOpen) {
      this.editing[row.id + "-" + col.name] = false;
    }
  }

  showModal(): void {
    this.isVisible = true;
  }

  isValidArr(arr: any) {
    return this.helperService.isValidArr(arr);
  }

  showNotification(info: any) {
    this.notificationService.showNotification(info);
  }
  addColorCodes(statuses: any) {
    let colorCodes = AppConstants.SHOT_STATUS_CODES;
    statuses.map((item: any) => {
      item.code = colorCodes[item.value];
      return item;
    });
    console.log(statuses);
  }

  disabledShootingDate = (startValue: Date): boolean => {
    if (!startValue) {
      return false;
    }
    let today = new Date();
    let yesterday = new Date(today.setDate(today.getDate() - 1));
    return startValue.getTime() < yesterday.getTime();
  };

  async updateDateValue(row: any, col: any, event: any) {
    let prev = this.helperService.transformDate(row[col.name]);
    let curr = this.helperService.transformDate(event);
    if (prev != curr) {
      let shotId = row.id;
      let shotIn = {
        type: col.name
      };
      let dateISOStr = event.toISOString();
      if (dateISOStr.indexOf("T") > -1) {
        shotIn[col.name] = dateISOStr.split("T")[0]; // + 'T00:00:00.000Z';
        //curr; //event.toISOString();
      }

      await this.updateConfirm(row, col, shotId, shotIn);
    }
    if (this.isEditSuccess) {
      row[col.name] = event;
    }
  }

  async updateValue(row: any, col: any, event: any) {
    if (row[col.name] != event.target.value) {
      let shotId = row.id;
      let shotIn = {
        type: col.name
      };
      shotIn[col.name] = event.target.value;
      await this.updateConfirm(row, col, shotId, shotIn);
    }
    if (this.isEditSuccess) {
      row[col.name] = event.target.value;
    }
    this.editing[row.id + "-" + col.name] = false;
  }

  async updateConfirm(row: any, col: any, shotId: any, shotIn: any) {
    this.isEditSuccess = false;
    let errorMessage = "Record update failed.";
    await this.showsService
      .inlineEditShot(shotId, shotIn)
      .toPromise()
      .then((resp: any) => {
        console.log("update success ");
        this.isEditSuccess = true;
      })
      .catch((error: any) => {
        console.log("update failed ");
        let errorDetails = this.helperService.getErrorDetails(error);
        if (errorDetails !== "") {
          errorMessage = `<b>${errorMessage}</b>` + errorDetails;
        }
        this.isEditSuccess = false;
      });
    if (this.isEditSuccess) {
      this.showNotification({
        type: "success",
        title: "Success",
        content: "Record updated successfully.",
        duration: AppConstants.NOTIFICATION_DURATION
      });
    } else {
      this.showNotification({
        type: "error",
        title: "Error",
        content: errorMessage,
        duration: AppConstants.NOTIFICATION_DURATION
      });
    }
  }

  async getSequences() {
    await this.sequencesService
      .getSequenceList(this.showId)
      .toPromise()
      .then((resp: any) => {
        this.sequences = resp.entity;
      })
      .catch((error: any) => {
        this.sequences = [];
      });
  }

  async getStatuses() {
    await this.showsService
      .getAllStatus()
      .toPromise()
      .then((resp: any) => {
        this.statuses = resp.entity;
        this.addColorCodes(this.statuses);
      })
      .catch((error: any) => {
        this.statuses = [];
      });
  }

  async getSupervisors() {
    await this.showsService
      .getSupervisorsByShowId(this.showId)
      .toPromise()
      .then((resp: any) => {
        this.supervisors = resp.entity;
      })
      .catch((error: any) => {
        this.supervisors = [];
      });
  }
}
