import { Injectable } from '@angular/core';

import { environment } from "src/environments/environment";
import { AppConstants } from "src/app/constants/AppConstants";
import { LoggerService } from '../core/services/logger.service';
import { HttpService } from '../core/services/http.service';


@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  /** Variables declarations - START */
  private apiUrl = environment.apiUrl;
  private apiUrlLocal = environment.apiUrlLocal;
  isLocal = environment.isLocal;
  /** Variables declarations - END */

  constructor(private http: HttpService, private logger: LoggerService) { }

  getNotificationList(page: any) {
    let params = ``;
    if (page) {
      params += `search=${page.search}&pageNo=${page.pageNumber}&pageSize=${page.size}&sortBy=${page.sortBy}&orderBy=${page.orderBy}`;
    }
    let endPoint = this.apiUrl + AppConstants.NOTIFICATION_LIST + "/?" + params;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "notification-list";
    }
    this.logger.log("NotificationsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }

  markNotificationAsRead(id: any) {
    const endPoint = this.apiUrl + AppConstants.NOTIFICATION_READ + "/" + id;
    this.logger.log("NotificationsService Calling endpoint " + endPoint);
    return this.http.put<any>(endPoint, null);
  }

  checkNewNotifications(_time: any) {
    let time = '';
    if (_time) {
      time = _time;
    }
    let endPoint = this.apiUrl + AppConstants.NOTIFICATION_LATEST + "?date=" + time;
    if (this.isLocal) {
      endPoint = this.apiUrlLocal + "notification-latest";
    }
    this.logger.log("NotificationsService Calling endpoint " + endPoint);
    return this.http.get<any>(endPoint);
  }


}
