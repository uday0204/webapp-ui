import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DaybookHomeComponent } from './daybook-home/daybook-home.component';


const routes: Routes = [
  { path: "", component: DaybookHomeComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DaybookRoutingModule { }
