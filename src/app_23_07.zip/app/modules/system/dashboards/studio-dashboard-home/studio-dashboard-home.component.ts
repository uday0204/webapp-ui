import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { StudioDashboardComponent } from '../studio-dashboard/studio-dashboard.component';
import { NzDrawerService } from "ng-zorro-antd";
import { WorkstatusService } from '../../configs/workstatus.service';
import { HelperService } from 'src/app/modules/core/services/helper.service';
import { ShowsService } from '../../shows/shows.service';
import { AppConstants } from 'src/app/constants/AppConstants';
import { StudioDbSettingsComponent } from '../../modals/studio-db-settings/studio-db-settings.component';

@Component({
  selector: 'app-studio-dashboard-home',
  templateUrl: './studio-dashboard-home.component.html',
  styleUrls: ['./studio-dashboard-home.component.scss']
})
export class StudioDashboardHomeComponent implements OnInit {
  @ViewChild("drawerHeader", { static: false }) drawerHeader: TemplateRef<{}>;
  @ViewChild(StudioDashboardComponent, { static: false }) studioDashboardComponent: StudioDashboardComponent;

  isDashboardVisible: boolean;
  isDaybookVisible: boolean;
  drawerTitle: any;
  childDrawerRef: any;
  statuses: any;
  overallSelectedItems: any;
  starSelectedItems: any;
  starUserSelectedItems: any;

  constructor(
    private drawerService: NzDrawerService,
    private showsService: ShowsService,
    private helperService: HelperService
  ) { }

  ngOnInit() {
    this.drawerTitle = "Studio Dashboard Settings";
    this.showDashboard();
    //this.showDaybook();
    this.getStatuses();
  }

  async getStatuses() {
    await this.showsService
      .getAllStatus()
      .toPromise()
      .then((resp: any) => {
        this.statuses = resp.entity;
        this.addColorCodes(this.statuses);
        this.overallSelectedItems = this.statuses.slice(0, 5);
        this.starSelectedItems = this.statuses.slice(0, 4);
        this.starUserSelectedItems = this.statuses.slice(0, 2);
      })
      .catch((error: any) => {
        this.statuses = [];
      });
  }

  addColorCodes(statuses: any) {
    let colorCodes = AppConstants.SHOT_STATUS_CODES;
    statuses.map((item: any) => {
      item.code = colorCodes[item.value];
      return item;
    });
    console.log(statuses);
  }

  showDashboard() {
    this.isDashboardVisible = true;
    this.isDaybookVisible = false;
  }
  showDaybook() {
    this.isDashboardVisible = false;
    this.isDaybookVisible = true;
  }
  showSettings() {
    this.openDashboardSettings();
  }

  isValidArr(arr: any) {
    return this.helperService.isValidArr(arr);
  }

  closeForm(): void {
    this.childDrawerRef.close();
  }

  openDashboardSettings(): void {
    this.childDrawerRef = this.drawerService.create<
      StudioDbSettingsComponent,
      {
        statuses: any;
        overallSelectedItems: any;
        starSelectedItems: any;
        starUserSelectedItems: any;
      },
      string
    >({
      nzTitle: this.drawerHeader,
      nzContent: StudioDbSettingsComponent,
      nzContentParams: {
        statuses: this.statuses,
        overallSelectedItems: this.overallSelectedItems,
        starSelectedItems: this.starSelectedItems,
        starUserSelectedItems: this.starUserSelectedItems
      },
      nzClosable: false,
      nzWidth: "40%",
      nzWrapClassName: "modal-wrapper"
    });

    this.childDrawerRef.afterOpen.subscribe(() => {
      console.log("childDrawerRef Drawer(Component) open");
    });

    this.childDrawerRef.afterClose.subscribe(data => {
      if (data) {
        let result = JSON.parse(data);
        if (!this.helperService.isSameObject(this.overallSelectedItems, result.overallSelectedItems)) {
          this.overallSelectedItems = result.overallSelectedItems;
          this.studioDashboardComponent.updateOverallStatus(this.overallSelectedItems);
        }
        if (!this.helperService.isSameObject(this.starSelectedItems, result.starSelectedItems)) {
          this.starSelectedItems = result.starSelectedItems;
          this.studioDashboardComponent.updateStarStatus(this.starSelectedItems);
        }

        if (!this.helperService.isSameObject(this.starUserSelectedItems, result.starUserSelectedItems)) {
          this.starUserSelectedItems = result.starUserSelectedItems;
          this.studioDashboardComponent.updateStarUserStatus(this.starUserSelectedItems);
        }



      }
    });
  }

}
