import { Component, OnInit } from "@angular/core";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { InteractionService } from "src/app/modules/core/services/interaction.service";
import { Role } from "src/app/modules/shared/model/role";
import { Router } from '@angular/router';

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"]
})
export class DashboardComponent implements OnInit {
  dashboardType: any;
  constructor(
    private helperService: HelperService,
    private interactionService: InteractionService,
    private router: Router,
  ) { }

  ngOnInit() {
    this.interactionService.sendInteraction("breadcrumb", "hide_breadcrumb");
    this.dashboardType = this.setDashboardType();
  }
  setDashboardType() {
    let dashboardType = ""; //artist //studio
    let currentUserRole = this.helperService.getRole();
    switch (currentUserRole) {
      case Role.ADMIN:
      case Role.HOS:
        dashboardType = "admin";
        break;
      case Role.ARTIST:
        dashboardType = "artist";
        break;
      case Role.CLIENT:
        dashboardType = "client";
        break;
      case Role.PRODUCER:
      case Role.SUPERVISOR:
      case Role.IO:
        dashboardType = "studio";
        break;
      case Role.HR:
        dashboardType = "hr";
        break;
    }
    //}

    if (dashboardType === '') {
      if (currentUserRole === Role.PLATFORM_ADMIN) {
        this.router.navigate(["/system/listing/configs"]);
      }
    } else {
      return dashboardType;
    }
  }
}
