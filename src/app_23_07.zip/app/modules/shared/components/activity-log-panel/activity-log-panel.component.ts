import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { HelperService } from "src/app/modules/core/services/helper.service";
import { StudioDashboardService } from "src/app/modules/system/dashboards/studio-dashboard.service";
import { Page } from "../../model/page";
import { ArtistDashboardService } from "src/app/modules/system/dashboards/artist-dashboard.service";

@Component({
  selector: "app-activity-log-panel",
  templateUrl: "./activity-log-panel.component.html",
  styleUrls: ["./activity-log-panel.component.scss"]
})
export class ActivityLogPanelComponent implements OnInit {
  @Input() panelHeight: any;
  @Input() parent: any;

  isDataEmpty: boolean;
  activityLogs: any;

  isDataReady: boolean;
  isLoading: boolean;
  windowHeight: any;
  itemsCount: any;
  pageNumber: any;
  page = new Page();
  macroMap: any;
  macroArr: any;

  constructor(
    private helperService: HelperService,
    private sutdioDashboardService: StudioDashboardService,
    private artistDashboardService: ArtistDashboardService
  ) { }

  ngOnInit() {
    console.log("ngOnInit " + this.panelHeight);
    this.macroArr = [
      "USER_NAME",
      "ENTITY_NAME",
      "ASSIGNED_USER_NAME",
      "STATUS"
    ];
    this.macroMap = {
      USER_NAME: {
        key: "userName",
        className: "n-user"
      },
      ENTITY_NAME: {
        key: "entityName",
        className: "n-entity"
      },
      ASSIGNED_USER_NAME: {
        key: "assignedUserName",
        className: "n-user"
      },
      STATUS: {
        key: "statusName",
        className: "n-user"
      }
    };
    this.pageNumber = 0;
    this.getActivityLogs();
  }

  onPageIndexChange(event: any) {
    this.pageNumber = event - 1;
    this.getActivityLogs();
  }

  async getActivityLogs() {
    let availHeight = this.panelHeight - 150;
    let itemHeight = 70;
    this.itemsCount = Math.floor(availHeight / itemHeight);
    this.page.pageNumber = this.pageNumber;
    this.page.size = this.itemsCount;
    this.isLoading = true;
    if (this.parent === "artist") {
      await this.artistDashboardService
        .getActivityLogs(this.page)
        .toPromise()
        .then(resp => {
          this.activityLogs = resp.coll;
          this.page.totalElements = resp.total;
          this.page.totalPages = Math.ceil(resp.total / this.page.size);
        })
        .catch(error => {
          this.activityLogs = null;
        });
      if (this.activityLogs && this.activityLogs.length > 0) {
        this.isDataEmpty = false;
      } else {
        this.isDataEmpty = true;
      }
    } else {
      await this.sutdioDashboardService
        .getActivityLogs(this.page)
        .toPromise()
        .then(resp => {
          if (resp && resp.valid) {
            this.activityLogs = resp.coll;
            this.page.totalElements = resp.total;
            this.page.totalPages = Math.ceil(resp.total / this.page.size);
          }
        })
        .catch(error => {
          this.activityLogs = null;
        });
      if (this.activityLogs && this.activityLogs.length > 0) {
        this.isDataEmpty = false;
      } else {
        this.isDataEmpty = true;
      }
    }
    this.isLoading = false;
  }

  getLogType(item: any) {
    let logType = "";
    if (item.eventType === "WORK_STATUS" || item.eventType === "STATUS") {
      logType = "status_change";
    } else if (item.eventType === "ASSIGNED") {
      logType = "assign";
    }
    return logType;
  }

  getTitle(item: any) {
    try {
      if (this.getLogType(item) === "status_change") {
        return `${
          item.userName
          } changed status of ${item.entityType.toLowerCase()} ${
          item.entityName
          } to ${item.eventDetail}`;
      } else if (this.getLogType(item) === "assign") {
        return `${item.userName} assigned ${item.entityType.toLowerCase()} ${
          item.entityName
          } to ${item.eventDetail}`;
      }
    } catch (e) {
      return "";
    }
  }

  get12Format(time: any) {
    return this.helperService.convertFrom24To12Format(time);
  }

  refreshHandler() {
    this.pageNumber = 0;
    this.getActivityLogs();
  }

  getMsg(data: any) {
    let msg = "";
    try {
      if (
        data &&
        data.activityLogDetailVo &&
        data.activityLogDetailVo.message
      ) {
        msg = data.activityLogDetailVo.message;
        msg = this.replaceMacros(data, msg);
      }
    } catch (e) { }
    return msg;
  }

  replaceMacros(data: any, _msg: string) {
    let msg = _msg;
    let macroInfo = null;
    let macroKey = null;
    let macroStr = null;
    let replaceMacro = null;
    let macroValue = "";
    for (let i = 0; i < this.macroArr.length; i++) {
      macroKey = this.macroArr[i];
      macroInfo = this.macroMap[this.macroArr[i]];
      macroStr = `<${macroKey}>`;
      replaceMacro = `<span class='${macroInfo.className}'>${macroStr}</span>`;
      if (msg.indexOf(macroStr) > -1) {
        msg = msg.split(macroStr).join(replaceMacro);
        if (data.activityLogDetailVo[macroInfo.key]) {
          macroValue = data.activityLogDetailVo[macroInfo.key];
        }
        msg = msg.split(macroStr).join(macroValue);
      }
    }
    return msg;
  }
}
