import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { UploadFile, UploadXHRArgs, UploadChangeParam } from "ng-zorro-antd";
import { ShowsService } from "src/app/modules/system/shows/shows.service";

@Component({
  selector: "app-image-upload",
  templateUrl: "./image-upload.component.html",
  styleUrls: ["./image-upload.component.scss"]
})
export class ImageUploadComponent implements OnInit {
  @Input() imageUrl: any;
  @Input() showPreview: any = true;
  @Output() onChange = new EventEmitter<UploadChangeParam>();

  showUploadList = {
    showPreviewIcon: this.showPreview,
    showRemoveIcon: true,
    hidePreviewIconInNonImage: true
  };
  /*fileList: UploadFile[] = [
    {
      uid: -1,
      name: 'thumb.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png'
    }
  ];*/

  fileList: any = [];
  previewImage: string | undefined = "";
  previewVisible = false;

  constructor(private showsService: ShowsService) { }

  ngOnInit() {
    this.showUploadList.showPreviewIcon = this.showPreview;
    if (this.imageUrl) {
      this.fileList = [
        {
          uid: -1,
          name: "thumb.png",
          status: "done",
          url: this.imageUrl
        }
      ];
    }
  }

  handlePreview = (file: UploadFile) => {
    this.previewImage = file.url || file.thumbUrl;
    this.previewVisible = true;
  };

  handleUpload = async (item: UploadXHRArgs) => {
    const formData = new FormData();
    formData.append("file", item.file as any);
    formData.append("id", "1000");
    await this.showsService
      .uploadFile(formData)
      .toPromise()
      .then((resp: any) => { })
      .catch((error: any) => { });
  };

  uploadAPI = () => {
    return this.showsService.uploadFileEndPoint();
  };

  uploadMonitor = (e: UploadChangeParam) => {
    this.onChange.emit(e);
  };
}
