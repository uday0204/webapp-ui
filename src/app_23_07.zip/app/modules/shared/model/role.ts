export enum Role {
    ARTIST = 'Artist',
    ADMIN = 'Admin',
    CLIENT = 'Client',
    PRODUCER = 'Producer',
    SUPERVISOR = 'Supervisor',
    IO = 'I/O',
    HR = 'HR',
    HOS = 'Head of Studio',
    PLATFORM_ADMIN = 'Platform Administrator'
}