import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
 import { LoginComponent } from './login/login.component';
 import { AccountHomeComponent } from './account-home/account-home.component';


const routes: Routes = [
   {
    path: '',
    children: [
      { path: '', redirectTo: '/login', pathMatch: 'full' },
      {
        path: 'login',
        component: AccountHomeComponent,
        children: [
          { path: '', component: LoginComponent }
        ]
      }
    ]
  }
];



/*const routes2: Routes = [
  {
    path: '', canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: '/system/listing', pathMatch: 'full' },
      {
        path: 'listing',
        children: [
          {
            path: '',
            children: [
              { path: '', component: ListingComponent }
            ]
          },
          { path: 'role-listing', loadChildren: () => import('./roles/roles.module').then(m => m.RolesModule) },
        ]
      },
      { path: 'help', children: [{ path: '', component: HelpComponent }] },
      { path: 'settings', children: [{ path: '', component: SettingsComponent }] },
    ]
  }
];*/

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
